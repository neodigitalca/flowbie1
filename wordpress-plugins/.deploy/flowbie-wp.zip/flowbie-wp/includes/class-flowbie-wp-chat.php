<?php
/**
 * Flowbie Chat Widget: frontend injection and REST API.
 *
 * When enabled in Settings > Chat Widget, injects a chat panel host in wp_footer
 * that merges with the AI Search magnifying-glass sidebar. The REST endpoint at
 * flowbie/v1/chat handles messages using RAG + three-phase sub-agent reasoning.
 *
 * @package Flowbie_Wp
 */

defined( 'ABSPATH' ) || exit;

class Flowbie_Wp_Chat {

	const OPTION_KEY     = 'flowbie_wp_chat_settings';
	const REST_NAMESPACE = 'flowbie/v1';

	/**
	 * Hook registrations.
	 */
	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'wp_footer', array( __CLASS__, 'maybe_render_widget' ), 100 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue_assets' ) );
		add_action( 'save_post', array( __CLASS__, 'on_post_save' ), 10, 0 );

		add_action( 'wp_ajax_flowbie_chat_stream', array( __CLASS__, 'ajax_chat_stream' ) );
		add_action( 'wp_ajax_nopriv_flowbie_chat_stream', array( __CLASS__, 'ajax_chat_stream' ) );
	}

	/**
	 * Whether the chat widget is enabled.
	 */
	public static function is_enabled(): bool {
		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) || ! array_key_exists( 'enabled', $stored ) ) {
			return false;
		}
		return ! empty( $stored['enabled'] );
	}

	/**
	 * Whether the chat widget should load for the current frontend visitor.
	 * When logged_in_only is set, guests do not see the widget or receive chat API access.
	 */
	public static function should_show_for_visitor(): bool {
		if ( ! self::is_enabled() ) {
			return false;
		}
		$settings = self::get_settings();
		if ( ! empty( $settings['logged_in_only'] ) && ! is_user_logged_in() ) {
			return false;
		}
		return true;
	}

	/**
	 * Get all chat settings with defaults.
	 *
	 * @return array{enabled:bool,welcome_message:string,color:string}
	 */
	public static function get_settings(): array {
		$defaults = array(
			'enabled'             => false,
			'logged_in_only'        => false,
			'welcome_message'     => __( 'Hi! Ask me anything about this website.', 'flowbie-wp' ),
			'color'               => '#3b82f6',
			'assistant_name'      => 'Flow Assist',
			'system_prompt'       => '',
			'greeting_style'      => 'friendly',
			'knowledge_base'      => array(),
			'indexed_post_types'  => array( 'post', 'page' ),
			'excluded_categories' => array(),
			'full_content'        => false,
			'voice_enabled'       => true,
			'voice_ptt'           => true,
			'mic_replaces_send'   => true,
		);

		$stored = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		$merged = array_merge( $defaults, $stored );
		$sidebar = Flowbie_Wp_Ai_Widget_Design::resolve_sidebar_config( 'chat', $stored );

		return array_merge( $merged, $sidebar );
	}

	/**
	 * Default conversation starter prompts (demo + frontend empty state).
	 *
	 * @return array<int, string>
	 */
	public static function default_conversation_starters(): array {
		return array(
			__( 'Where should I start as a new client?', 'flowbie-wp' ),
			__( 'What services do you offer?', 'flowbie-wp' ),
			__( 'How do I book an appointment?', 'flowbie-wp' ),
		);
	}

	/**
	 * Save chat settings.
	 *
	 * @param array $settings
	 */
	public static function save_settings( array $settings ): void {
		$current = self::get_settings();
		$merged  = array_merge( $current, $settings );
		update_option( self::OPTION_KEY, $merged );
	}

	/**
	 * Register REST route for chat messages.
	 */
	public static function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/chat',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_chat' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/chat/accept',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_chat_accept' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * REST handler: process a chat message through the RAG + sub-agent pipeline.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public static function rest_chat( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::is_enabled() && ! current_user_can( 'manage_options' ) ) {
			return new WP_REST_Response(
				array( 'error' => __( 'Chat widget is not enabled.', 'flowbie-wp' ) ),
				403
			);
		}
		if ( ! self::should_show_for_visitor() && ! current_user_can( 'manage_options' ) ) {
			return new WP_REST_Response(
				array( 'error' => __( 'Chat is available to logged-in users only.', 'flowbie-wp' ) ),
				403
			);
		}

		$api_key = Flowbie_Wp_OpenRouter::get_api_key();
		if ( $api_key === '' ) {
			return new WP_REST_Response(
				array( 'error' => __( 'AI is not configured. Please ask the site administrator to add an OpenRouter API key.', 'flowbie-wp' ) ),
				503
			);
		}

		$body    = $request->get_json_params();
		$message = isset( $body['message'] ) ? sanitize_textarea_field( wp_unslash( $body['message'] ) ) : '';
		$history = isset( $body['history'] ) && is_array( $body['history'] ) ? $body['history'] : array();
		$log_meta = Flowbie_Wp_Chat_Logs::parse_meta_from_body( is_array( $body ) ? $body : null );

		if ( trim( $message ) === '' ) {
			return new WP_REST_Response(
				array( 'error' => __( 'Message cannot be empty.', 'flowbie-wp' ) ),
				400
			);
		}

		$history = Flowbie_Wp_Chat_History::normalize( $history );

		$site_name  = get_bloginfo( 'name' );
		$settings   = self::get_settings();
		$site_index = Flowbie_Wp_Chat_Rag::get_site_index( $settings );

		$training = array(
			'assistant_name' => $settings['assistant_name'],
			'system_prompt'  => $settings['system_prompt'],
			'greeting_style' => $settings['greeting_style'],
			'knowledge_base' => $settings['knowledge_base'],
		);

		Flowbie_Wp_Chat_Logs::log_user_message( $message, $log_meta );

		$card = Flowbie_Wp_Chat_Agents::run( $message, $history, $site_name, $site_index, $training, $settings );

		if ( is_array( $card ) ) {
			$message_uid = Flowbie_Wp_Chat_Logs::log_assistant_card( $card, $log_meta );
			if ( $message_uid !== '' ) {
				$card['message_uid'] = $message_uid;
			}
		}

		return new WP_REST_Response( $card, 200 );
	}

	/**
	 * REST handler: record accepted answer click.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_chat_accept( WP_REST_Request $request ): WP_REST_Response {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = array();
		}

		$result = Flowbie_Wp_Chat_Logs::record_accept(
			array(
				'message_uid' => isset( $body['messageId'] ) ? (string) $body['messageId'] : '',
				'url'         => isset( $body['url'] ) ? (string) $body['url'] : '',
				'label'       => isset( $body['label'] ) ? (string) $body['label'] : '',
				'type'        => isset( $body['type'] ) ? (string) $body['type'] : 'link',
			)
		);

		if ( empty( $result['ok'] ) ) {
			$status = ( isset( $result['error'] ) && $result['error'] === 'logging_disabled' ) ? 200 : 400;
			return new WP_REST_Response( $result, $status );
		}

		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * Enqueue chat widget assets on the frontend when enabled.
	 */
	public static function maybe_enqueue_assets(): void {
		if ( is_admin() || ! self::should_show_for_visitor() ) {
			return;
		}

		$base = plugin_dir_url( FLOWBIE_WP_PLUGIN_FILE ) . 'assets/frontend/';
		$ver  = FLOWBIE_WP_VERSION;

		wp_enqueue_style(
			'flowbie-wp-lato',
			'https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,600;0,700;1,400&display=swap',
			array(),
			null
		);

		wp_enqueue_style(
			'flowbie-chat-widget',
			$base . 'flowbie-chat-widget.css',
			array( 'flowbie-wp-lato' ),
			$ver
		);

		wp_enqueue_style(
			'flowbie-chat-chrome',
			$base . 'flowbie-chat-chrome.css',
			array( 'flowbie-chat-widget' ),
			$ver
		);

		Flowbie_Wp_Voice::enqueue_thinking_card_assets();

		$settings       = self::get_settings();
		$voice_enabled  = ! empty( $settings['voice_enabled'] ) && Flowbie_Wp_OpenRouter::get_api_key() !== '';
		$widget_deps    = array( 'flowbie-thinking-card', 'flowbie-chat-stream', 'flowbie-display-text', 'flowbie-markdown' );
		if ( $voice_enabled ) {
			Flowbie_Wp_Voice::enqueue_assets();
			$widget_deps[] = 'flowbie-voice';
		}
		Flowbie_Wp_Search::register_sidebar_assets();
		wp_enqueue_style( 'flowbie-ai-sidebar-shell' );
		wp_enqueue_style( 'flowbie-ai-sidebar-unify' );
		wp_enqueue_script( 'flowbie-ai-sidebar-shell' );
		wp_enqueue_script( 'flowbie-ai-sidebar-unify' );
		$widget_deps[] = 'flowbie-ai-sidebar-shell';
		$widget_deps[] = 'flowbie-ai-sidebar-unify';

		wp_enqueue_script(
			'flowbie-chat-widget',
			$base . 'flowbie-chat-widget.js',
			$widget_deps,
			$ver,
			true
		);

		$design   = Flowbie_Wp_Ai_Widget_Design::get_settings();
		$tokens   = Flowbie_Wp_Ai_Widget_Design::resolve( 'chat' );
		$css_vars = Flowbie_Wp_Ai_Widget_Design::build_chat_css_vars( $tokens );
		$css_vars .= Flowbie_Wp_Ai_Widget_Design::build_sidebar_css_vars( $settings, $tokens );

		$launcher_label   = isset( $settings['launcher_label'] ) ? trim( (string) $settings['launcher_label'] ) : '';
		if ( $launcher_label === '' ) {
			$launcher_label = sprintf(
				/* translators: %s: assistant display name */
				__( 'Open %s', 'flowbie-wp' ),
				(string) $settings['assistant_name']
			);
		}

		$assistant_name = (string) $settings['assistant_name'];
		$site_name      = get_bloginfo( 'name' );

		wp_localize_script(
			'flowbie-chat-widget',
			'flowbieChatConfig',
			array(
				'restUrl'                => esc_url_raw( rest_url( self::REST_NAMESPACE . '/chat' ) ),
				'acceptUrl'              => esc_url_raw( rest_url( self::REST_NAMESPACE . '/chat/accept' ) ),
				'nonce'                  => wp_create_nonce( 'wp_rest' ),
				'ajaxUrl'                => admin_url( 'admin-ajax.php' ),
				'streamNonce'            => wp_create_nonce( 'flowbie_chat_stream' ),
				'transcribeUrl'          => esc_url_raw( rest_url( Flowbie_Wp_Voice::REST_NAMESPACE . '/voice/transcribe' ) ),
				'siteName'               => $site_name,
				'welcomeMessage'         => $settings['welcome_message'],
				'color'                  => $settings['color'],
				'assistantName'          => $assistant_name,
				'cssVars'                => $css_vars,
				'ui'                     => $design['chat_ui'],
				'voiceEnabled'           => $voice_enabled,
				'voicePtt'               => ! empty( $settings['voice_ptt'] ),
				'micReplacesSend'        => ! empty( $settings['mic_replaces_send'] ),
				'sidebarSide'            => (string) ( $settings['sidebar_side'] ?? 'right' ),
				'sidebarTransition'      => (string) ( $settings['sidebar_transition'] ?? 'slide' ),
				'sidebarWidth'           => (int) ( $settings['sidebar_width'] ?? 400 ),
				'sidebarHeading'         => (string) ( $settings['sidebar_heading'] ?? '' ),
				'sidebarLayout'          => isset( $settings['sidebar_layout'] ) && is_array( $settings['sidebar_layout'] )
					? $settings['sidebar_layout']
					: array( 'chat' ),
				'launcherLabel'          => $launcher_label,
				'greetingLine'           => __( 'Hello', 'flowbie-wp' ),
				'greetingSubline'        => __( 'How can I help you today?', 'flowbie-wp' ),
				'conversationStarters'   => self::default_conversation_starters(),
				'composerPlaceholder'    => sprintf(
					/* translators: %s: site name */
					__( 'Ask about %s…', 'flowbie-wp' ),
					$site_name
				),
			)
		);
	}

	/**
	 * Render the widget mount point in the footer.
	 */
	public static function maybe_render_widget(): void {
		if ( is_admin() || ! self::should_show_for_visitor() ) {
			return;
		}

		echo '<div id="flowbie-chat-widget-root"></div>' . "\n";
	}

	/**
	 * Invalidate RAG cache when posts are saved.
	 */
	public static function on_post_save(): void {
		Flowbie_Wp_Chat_Rag::invalidate_cache();
	}

	/**
	 * AJAX streaming handler: runs the pipeline step-by-step, flushing
	 * NDJSON progress events so the frontend can show live status.
	 *
	 * Each line is a JSON object: {"status":"...","label":"..."} for progress,
	 * or {"status":"done","card":{...}} for the final result.
	 */
	public static function ajax_chat_stream(): void {
		check_ajax_referer( 'flowbie_chat_stream', '_nonce' );

		if ( ! self::is_enabled() && ! current_user_can( 'manage_options' ) ) {
			self::stream_line( array( 'status' => 'done', 'card' => array(
				'type' => 'not-found', 'title' => 'Disabled', 'body' => 'Chat widget is not enabled.', 'confidence' => 'low',
			) ) );
			wp_die();
		}
		if ( ! self::should_show_for_visitor() && ! current_user_can( 'manage_options' ) ) {
			self::stream_line( array( 'status' => 'done', 'card' => array(
				'type' => 'not-found', 'title' => 'Login required', 'body' => 'Chat is available to logged-in users only.', 'confidence' => 'low',
			) ) );
			wp_die();
		}

		$api_key = Flowbie_Wp_OpenRouter::get_api_key();
		if ( $api_key === '' ) {
			self::stream_line( array( 'status' => 'done', 'card' => array(
				'type' => 'not-found', 'title' => 'Not configured', 'body' => 'AI is not configured. Please add an OpenRouter API key.', 'confidence' => 'low',
			) ) );
			wp_die();
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$raw_body = file_get_contents( 'php://input' );
		$body     = json_decode( $raw_body, true );
		$message  = isset( $body['message'] ) ? sanitize_textarea_field( wp_unslash( $body['message'] ) ) : '';
		$history  = isset( $body['history'] ) && is_array( $body['history'] ) ? $body['history'] : array();
		$log_meta = Flowbie_Wp_Chat_Logs::parse_meta_from_body( is_array( $body ) ? $body : null );

		if ( trim( $message ) === '' ) {
			self::stream_line( array( 'status' => 'done', 'card' => array(
				'type' => 'not-found', 'title' => 'Empty message', 'body' => 'Message cannot be empty.', 'confidence' => 'low',
			) ) );
			wp_die();
		}

		Flowbie_Wp_Chat_Logs::log_user_message( $message, $log_meta );

		$history = Flowbie_Wp_Chat_History::normalize( $history );

		$settings   = self::get_settings();
		$site_name  = get_bloginfo( 'name' );
		$site_index = Flowbie_Wp_Chat_Rag::get_site_index( $settings );

		$training = array(
			'assistant_name' => $settings['assistant_name'],
			'system_prompt'  => $settings['system_prompt'],
			'greeting_style' => $settings['greeting_style'],
			'knowledge_base' => $settings['knowledge_base'],
		);

		// -- Begin streaming headers --
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Cache-Control: no-cache' );
		header( 'X-Accel-Buffering: no' );
		if ( function_exists( 'apache_setenv' ) ) {
			apache_setenv( 'no-gzip', '1' ); // @codeCoverageIgnore
		}
		while ( ob_get_level() ) {
			ob_end_flush();
		}

		// -- Secretary gate (before RAG) --
		$gate = Flowbie_Wp_Chat_Agents::phase_ack( $message, $site_name, array(), $training, $history );
		if ( is_wp_error( $gate ) ) {
			self::stream_line( array( 'status' => 'done', 'card' => array(
				'type' => 'not-found', 'title' => 'Something went wrong', 'body' => $gate->get_error_message(), 'confidence' => 'low',
			) ) );
			wp_die();
		}

		if ( is_array( $gate ) && trim( (string) ( $gate['text'] ?? '' ) ) !== '' ) {
			self::stream_line( array( 'status' => 'ack', 'text' => trim( (string) $gate['text'] ) ) );
		}

		if ( is_array( $gate ) && ( $gate['action'] ?? '' ) === 'deny' ) {
			$denial = Flowbie_Wp_Chat_Agents::build_denial_card(
				(string) ( $gate['text'] ?? '' ),
				$message,
				$site_name,
				$site_index,
				$history
			);
			$message_uid = Flowbie_Wp_Chat_Logs::log_assistant_card( $denial, $log_meta );
			if ( $message_uid !== '' ) {
				$denial['message_uid'] = $message_uid;
			}
			self::stream_line( array( 'status' => 'done', 'card' => $denial ) );
			wp_die();
		}

		// -- Instant retrieve (continue path) --
		$early_retrieved = Flowbie_Wp_Chat_Rag::retrieve( $message, Flowbie_Wp_Chat_Rag::MAX_RESULTS, $settings );
		if ( Flowbie_Wp_Chat_Links::detect_lead_action( $message ) ) {
			$lead_pages      = Flowbie_Wp_Chat_Links::find_lead_pages( $message, $site_index, 2 );
			$early_retrieved = Flowbie_Wp_Chat_Links::dedupe_items_by_id( array_merge( $lead_pages, $early_retrieved ) );
		}

		self::stream_line( array( 'status' => 'searching', 'label' => 'Searching content…' ) );

		$phase_a = Flowbie_Wp_Chat_Agents::synthesize_classification_from_retrieve( $message, $early_retrieved );
		if ( null === $phase_a ) {
			$narrow = Flowbie_Wp_Chat_Agents::build_narrow_candidate_items( $site_index, $message, $early_retrieved, $settings );
			$phase_a = Flowbie_Wp_Chat_Agents::phase_classify( $message, $site_name, $site_index, $narrow );
		}
		if ( is_wp_error( $phase_a ) ) {
			self::stream_line( array( 'status' => 'done', 'card' => array(
				'type' => 'not-found', 'title' => 'Something went wrong', 'body' => $phase_a->get_error_message(), 'confidence' => 'low',
			) ) );
			wp_die();
		}

		$relevant_items = Flowbie_Wp_Chat_Agents::select_relevant_items( $phase_a, $site_index, $message, $settings );

		$enriched_items = self::enrich_relevant_items( $relevant_items, true, $settings );

		// -- Phase B: reason --
		self::stream_line( array( 'status' => 'thinking', 'label' => 'Thinking…' ) );

		$phase_b = Flowbie_Wp_Chat_Agents::phase_reason( $message, $history, $site_name, $enriched_items, $phase_a, $training, $site_index );
		if ( is_wp_error( $phase_b ) ) {
			self::stream_line( array( 'status' => 'done', 'card' => array(
				'type' => 'not-found', 'title' => 'Something went wrong', 'body' => $phase_b->get_error_message(), 'confidence' => 'low',
			) ) );
			wp_die();
		}

		// -- Deterministic card (skip Phase C LLM in stream) --
		self::stream_line( array( 'status' => 'formatting', 'label' => 'Formatting response…' ) );

		$phase_c = Flowbie_Wp_Chat_Agents::build_card_from_answer( $phase_b, $phase_a, $enriched_items, $message, $site_index, $history );

		if ( is_array( $phase_c ) ) {
			$message_uid = Flowbie_Wp_Chat_Logs::log_assistant_card( $phase_c, $log_meta );
			if ( $message_uid !== '' ) {
				$phase_c['message_uid'] = $message_uid;
			}
		}

		$done_payload = array( 'status' => 'done', 'card' => $phase_c );
		if ( isset( $log_meta['source'] ) && $log_meta['source'] === 'demo' && current_user_can( 'manage_options' ) ) {
			$done_payload['debug'] = self::build_demo_debug_payload(
				$message,
				$phase_a,
				$enriched_items,
				$site_index
			);
		}

		self::stream_line( $done_payload );
		wp_die();
	}

	/**
	 * Demo-only RAG debug snapshot (no full post bodies).
	 *
	 * @param array<string,mixed>              $phase_a
	 * @param array<int,array<string,mixed>>   $enriched_items
	 * @param array<int,array<string,mixed>>   $site_index
	 * @return array<string,mixed>
	 */
	private static function build_demo_debug_payload( string $user_message, array $phase_a, array $enriched_items, array $site_index ): array {
		$extra_phrases = isset( $phase_a['search_terms'] ) ? array_values( (array) $phase_a['search_terms'] ) : array();
		$match_terms   = Flowbie_Wp_Chat_Rag::extract_match_terms( $user_message, $extra_phrases );

		$retrieved = array();
		foreach ( $enriched_items as $item ) {
			$retrieved[] = array(
				'id'             => isset( $item['id'] ) ? (int) $item['id'] : 0,
				'title'          => isset( $item['title'] ) ? (string) $item['title'] : '',
				'url'            => isset( $item['url'] ) ? (string) $item['url'] : '',
				'slug'           => isset( $item['slug'] ) ? (string) $item['slug'] : '',
				'type'           => isset( $item['type'] ) ? (string) $item['type'] : '',
				'score'          => Flowbie_Wp_Chat_Rag::fuzzy_page_score( $user_message, $item, $extra_phrases ),
				'slug_term_hits' => Flowbie_Wp_Chat_Rag::count_slug_path_term_hits( $user_message, $item, $extra_phrases ),
				'excerpt_length' => isset( $item['excerpt'] ) ? strlen( (string) $item['excerpt'] ) : 0,
			);
		}

		$primary    = Flowbie_Wp_Chat_Links::pick_primary_topic_link( $user_message, $enriched_items, $site_index, $extra_phrases );
		$topics     = Flowbie_Wp_Chat_Links::pick_topic_links( $user_message, $enriched_items, 3, $site_index, true, $extra_phrases );
		$fuzzy_top  = Flowbie_Wp_Chat_Rag::find_fuzzy_topic_pages( $user_message, $site_index, 5, $extra_phrases );
		$url_hits   = Flowbie_Wp_Chat_Rag::index_url_term_hits( $user_message, $site_index, $extra_phrases );
		$type_counts = array();
		foreach ( $site_index as $item ) {
			$t = isset( $item['type'] ) ? (string) $item['type'] : 'unknown';
			$type_counts[ $t ] = ( $type_counts[ $t ] ?? 0 ) + 1;
		}

		return array(
			'timestamp'              => gmdate( 'c' ),
			'user_message'           => $user_message,
			'match_terms'            => array_values( $match_terms ),
			'index_count'            => count( $site_index ),
			'index_source'           => array(
				'source'     => 'sitemap',
				'post_types' => Flowbie_Wp_Chat_Rag::get_index_post_types( $settings ),
				'type_counts' => $type_counts,
			),
			'phase_a'                => array(
				'intent'       => isset( $phase_a['intent'] ) ? (string) $phase_a['intent'] : '',
				'relevant_ids' => isset( $phase_a['relevant_ids'] ) ? array_map( 'intval', (array) $phase_a['relevant_ids'] ) : array(),
				'search_terms' => $extra_phrases,
			),
			'retrieved_items'        => $retrieved,
			'url_term_hits'          => $url_hits,
			'fuzzy_top_5'            => array_map(
				function ( $item ) {
					return array(
						'id'    => isset( $item['id'] ) ? (int) $item['id'] : 0,
						'title' => isset( $item['title'] ) ? (string) $item['title'] : '',
						'slug'  => isset( $item['slug'] ) ? (string) $item['slug'] : '',
						'url'   => isset( $item['url'] ) ? (string) $item['url'] : '',
						'score' => isset( $item['fuzzy_score'] ) ? (float) $item['fuzzy_score'] : 0,
					);
				},
				$fuzzy_top
			),
			'topic_link_primary'     => null !== $primary ? array(
				'label' => $primary['label'],
				'url'   => $primary['url'],
				'score' => isset( $primary['score'] ) ? (float) $primary['score'] : 0,
			) : null,
			'topic_links'            => array_map(
				function ( $link ) {
					return array(
						'label' => $link['label'],
						'url'   => $link['url'],
						'score' => isset( $link['score'] ) ? (float) $link['score'] : 0,
					);
				},
				$topics
			),
			'enriched_excerpt_lengths' => array_map(
				function ( $item ) {
					return isset( $item['excerpt'] ) ? strlen( (string) $item['excerpt'] ) : 0;
				},
				$enriched_items
			),
		);
	}

	/**
	 * Flush a single NDJSON line to the output stream.
	 *
	 * @param array $data JSON-serialisable payload.
	 */
	private static function stream_line( array $data ): void {
		if ( isset( $data['card'] ) && is_array( $data['card'] ) ) {
			$data['card'] = Flowbie_Wp_Display_Text::decode_card( $data['card'] );
		}
		echo wp_json_encode( $data ) . "\n";
		if ( ob_get_level() ) {
			ob_flush();
		}
		flush();
	}

	/**
	 * Fetch rendered post content for all relevant items before Phase B.
	 *
	 * @param array $items               Relevant items from select_relevant_items().
	 * @param bool  $emit_reading_events Stream NDJSON reading events when true.
	 * @param array $settings            Chat settings (full_content gate).
	 * @return array Items with excerpt replaced by full content when enabled.
	 */
	public static function enrich_relevant_items( array $items, bool $emit_reading_events = false, array $settings = array() ): array {
		if ( empty( $items ) ) {
			return $items;
		}

		$items = array_slice( $items, 0, Flowbie_Wp_Chat_Rag::ENRICH_MAX );
		$full_content = ! empty( $settings['full_content'] );

		if ( ! $full_content ) {
			return $items;
		}

		if ( $emit_reading_events ) {
			self::stream_line(
				array(
					'status' => 'reading',
					'label'  => 'Reading matched pages…',
				)
			);
		}

		foreach ( $items as $i => $item ) {
			$post = get_post( $item['id'] );
			if ( ! $post || $post->post_status !== 'publish' ) {
				continue;
			}

			if ( $emit_reading_events ) {
				self::stream_line(
					array(
						'status' => 'reading',
						'label'  => 'Reading ' . $item['title'] . '…',
					)
				);
			}

			$full = Flowbie_Wp_Chat_Rag::read_post_body_for_chat( $post->ID );
			if ( $full !== '' ) {
				$items[ $i ]['excerpt'] = $full;
			}
		}

		return $items;
	}
}
