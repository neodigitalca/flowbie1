<?php
/**
 * Deterministic link grep and card attachment for Flowbie Chat.
 *
 * @package Flowbie_Wp
 */

defined( 'ABSPATH' ) || exit;

class Flowbie_Wp_Chat_Links {

	/**
	 * Prompt block listing title → URL for retrieved items.
	 *
	 * @param array<int,array<string,mixed>> $items RAG items with title + url.
	 */
	public static function build_links_context_block( array $items ): string {
		$lines = array();
		foreach ( $items as $item ) {
			if ( empty( $item['url'] ) || empty( $item['title'] ) ) {
				continue;
			}
			$lines[] = '- ' . $item['title'] . ' → ' . $item['url'];
		}
		return implode( "\n", $lines );
	}

	/**
	 * Keep only links whose URL exists in the filtered site index.
	 *
	 * @param array<int,array<string,mixed>>           $links
	 * @param array<int,array<string,mixed>>           $site_index
	 * @return array<int,array<string,mixed>>
	 */
	public static function filter_links_to_index( array $links, array $site_index ): array {
		if ( empty( $links ) || empty( $site_index ) ) {
			return $links;
		}

		$allowed = array();
		foreach ( $site_index as $item ) {
			if ( empty( $item['url'] ) ) {
				continue;
			}
			$allowed[ strtolower( rtrim( (string) $item['url'], '/' ) ) ] = true;
		}

		if ( empty( $allowed ) ) {
			return array();
		}

		$out = array();
		foreach ( $links as $link ) {
			$url = isset( $link['url'] ) ? (string) $link['url'] : '';
			if ( $url === '' ) {
				continue;
			}
			$norm = strtolower( rtrim( $url, '/' ) );
			if ( isset( $allowed[ $norm ] ) ) {
				$out[] = $link;
			}
		}

		return $out;
	}

	/**
	 * Detect high-intent lead actions from the user message.
	 *
	 * @return string|null booking|contact|pricing
	 */
	public static function detect_lead_action( string $message ): ?string {
		$terms    = Flowbie_Wp_Chat_Rag::extract_terms( $message );
		$term_set = array_flip( $terms );

		$booking = array( 'book', 'booking', 'appointment', 'schedule', 'scheduling', 'consultation', 'consult', 'reserve' );
		foreach ( $booking as $t ) {
			if ( isset( $term_set[ $t ] ) ) {
				return 'booking';
			}
		}

		$contact = array( 'contact', 'call', 'phone', 'email', 'reach', 'directions', 'location', 'hours' );
		foreach ( $contact as $t ) {
			if ( isset( $term_set[ $t ] ) ) {
				return 'contact';
			}
		}

		$pricing = array( 'price', 'pricing', 'cost', 'quote', 'estimate', 'rate', 'rates' );
		foreach ( $pricing as $t ) {
			if ( isset( $term_set[ $t ] ) ) {
				return 'pricing';
			}
		}

		return null;
	}

	/**
	 * Money-page slug list (shared with Site Search + chat lead routing).
	 *
	 * @return array<int,string>
	 */
	public static function money_page_slug_hints(): array {
		$base = array(
			'contact',
			'contact-us',
			'about',
			'about-us',
			'services',
			'our-services',
			'service',
			'pricing',
			'quote',
			'get-started',
			'locations',
			'consultation',
			'book',
			'appointment',
			'schedule',
		);

		$filtered = apply_filters( 'flowbie_wp_search_money_page_slugs', $base );
		return is_array( $filtered ) ? array_values( array_unique( array_map( 'strval', $filtered ) ) ) : $base;
	}

	/**
	 * Slug hints prioritized for a lead action type.
	 *
	 * @return array<int,string>
	 */
	private static function lead_action_slug_hints( string $action ): array {
		$map = array(
			'booking' => array( 'contact', 'contact-us', 'consultation', 'book', 'appointment', 'schedule', 'get-started' ),
			'contact' => array( 'contact', 'contact-us', 'about', 'about-us', 'locations' ),
			'pricing' => array( 'pricing', 'quote', 'get-started', 'services', 'our-services' ),
		);

		$hints = isset( $map[ $action ] ) ? $map[ $action ] : array();
		return array_values( array_unique( array_merge( $hints, self::money_page_slug_hints() ) ) );
	}

	/**
	 * Find indexed pages for a lead-intent message (contact, book, quote, etc.).
	 *
	 * @param array<int,array<string,mixed>> $site_index
	 * @return array<int,array<string,mixed>>
	 */
	public static function find_lead_pages( string $message, array $site_index, int $limit = 3 ): array {
		$action = self::detect_lead_action( $message );
		if ( null === $action || empty( $site_index ) || $limit < 1 ) {
			return array();
		}

		$hints  = self::lead_action_slug_hints( $action );
		$scored = array();

		foreach ( $site_index as $item ) {
			$score = self::score_lead_page_item( $item, $hints, $action );
			if ( $score <= 0 ) {
				continue;
			}
			$item['lead_score'] = $score;
			$scored[]           = $item;
		}

		if ( empty( $scored ) ) {
			return array();
		}

		usort(
			$scored,
			function ( $a, $b ) {
				return ( $b['lead_score'] ?? 0 ) <=> ( $a['lead_score'] ?? 0 );
			}
		);

		return array_slice( $scored, 0, $limit );
	}

	/**
	 * LINKS AVAILABLE block with lead pages prepended for Phase B.
	 *
	 * @param array<int,array<string,mixed>> $items
	 * @param array<int,array<string,mixed>> $site_index
	 */
	public static function build_links_context_block_for_reason( string $message, array $items, array $site_index ): string {
		$lead   = self::find_lead_pages( $message, $site_index, 3 );
		$merged = self::dedupe_items_by_id( array_merge( $lead, $items ) );
		return self::build_links_context_block( $merged );
	}

	/**
	 * @param array<string,mixed> $item
	 */
	private static function score_lead_page_item( array $item, array $hints, string $action ): float {
		if ( empty( $item['url'] ) ) {
			return 0.0;
		}

		$slug  = strtolower( (string) ( $item['slug'] ?? '' ) );
		$title = strtolower( wp_strip_all_tags( (string) ( $item['title'] ?? '' ) ) );
		$path  = strtolower( (string) wp_parse_url( (string) $item['url'], PHP_URL_PATH ) );
		$score = 0.0;

		foreach ( $hints as $hint ) {
			$hint = strtolower( (string) $hint );
			if ( $hint === '' ) {
				continue;
			}
			if ( self::slug_matches_hint( $slug, $hint ) ) {
				$score += 20.0;
			}
			if ( self::path_contains_hint( $path, $hint ) ) {
				$score += 15.0;
			}
			$hint_words = str_replace( '-', ' ', $hint );
			if ( $title !== '' && strpos( $title, $hint_words ) !== false ) {
				$score += 12.0;
			}
		}

		if ( $score <= 0 ) {
			return 0.0;
		}

		if ( isset( $item['type'] ) && (string) $item['type'] === 'page' ) {
			$score += 8.0;
		}

		if ( $action === 'booking' && ( self::slug_matches_hint( $slug, 'contact' ) || self::slug_matches_hint( $slug, 'consult' ) || strpos( $slug, 'consult' ) !== false ) ) {
			$score += 10.0;
		}

		return $score;
	}

	private static function slug_matches_hint( string $slug, string $hint ): bool {
		$slug = strtolower( trim( $slug, '/' ) );
		$hint = strtolower( trim( $hint, '/' ) );
		if ( $slug === '' || $hint === '' ) {
			return false;
		}
		if ( $slug === $hint ) {
			return true;
		}
		if ( str_starts_with( $slug, $hint . '-' ) || str_ends_with( $slug, '-' . $hint ) || strpos( $slug, '-' . $hint . '-' ) !== false ) {
			return true;
		}
		return in_array( $hint, explode( '-', $slug ), true );
	}

	private static function path_contains_hint( string $path, string $hint ): bool {
		$path = strtolower( trim( (string) $path, '/' ) );
		$hint = strtolower( trim( $hint, '/' ) );
		if ( $path === '' || $hint === '' ) {
			return false;
		}
		foreach ( explode( '/', $path ) as $segment ) {
			if ( self::slug_matches_hint( $segment, $hint ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 * @return array<int,array{label:string,url:string,icon:string}>
	 */
	public static function items_to_links( array $items ): array {
		$links = array();
		foreach ( $items as $item ) {
			if ( empty( $item['url'] ) || empty( $item['title'] ) ) {
				continue;
			}
			$links[] = array(
				'label' => (string) $item['title'],
				'url'   => (string) $item['url'],
				'icon'  => ( isset( $item['type'] ) && $item['type'] === 'post' ) ? 'post' : 'page',
			);
		}
		return $links;
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 * @return array<int,array<string,mixed>>
	 */
	public static function dedupe_items_by_id( array $items ): array {
		$out = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || empty( $item['id'] ) ) {
				continue;
			}
			$out[ (int) $item['id'] ] = $item;
		}
		return array_values( $out );
	}

	/**
	 * @param array<int,array{label:string,url:string,icon:string}> ...$groups
	 * @return array<int,array{label:string,url:string,icon:string}>
	 */
	private static function merge_link_groups( array ...$groups ): array {
		$merged = array();
		$seen   = array();
		foreach ( $groups as $group ) {
			foreach ( $group as $link ) {
				if ( empty( $link['url'] ) ) {
					continue;
				}
				$norm = strtolower( rtrim( (string) $link['url'], '/' ) );
				if ( isset( $seen[ $norm ] ) ) {
					continue;
				}
				$seen[ $norm ] = true;
				$merged[]      = $link;
			}
		}
		return $merged;
	}

	/**
	 * Grep site items for URLs relevant to the user message and drafted answer.
	 *
	 * @param array<int,array<string,mixed>> $items
	 * @param array<string,mixed>            $classification Phase A output.
	 * @return array<int,array{label:string,url:string,icon:string}>
	 */
	public static function grep_links_for_suggestion( string $user_message, string $answer, array $items, array $classification, array $site_index = array() ): array {
		$intent       = isset( $classification['intent'] ) ? (string) $classification['intent'] : 'question';
		$site_url     = home_url( '/' );
		$found        = array();
		$order        = array();
		$topic_intent = in_array( $intent, array( 'question', 'support' ), true );
		$phrases      = self::phrase_context( $classification );

		if ( $topic_intent ) {
			foreach ( self::pick_topic_links( $user_message, $items, 3, $site_index, true, $phrases ) as $link ) {
				$item = array(
					'title' => $link['label'],
					'url'   => $link['url'],
					'type'  => ( isset( $link['icon'] ) && $link['icon'] === 'post' ) ? 'post' : 'page',
				);
				self::add_link( $found, $order, $item, $site_url );
			}
		} else {
			foreach ( $items as $item ) {
				if ( empty( $item['url'] ) || empty( $item['title'] ) ) {
					continue;
				}
				if ( self::title_mentioned_in_text( (string) $item['title'], $answer ) ) {
					self::add_link( $found, $order, $item, $site_url );
				}
			}

			$harness_items = self::to_harness_items( $items );
			$query         = trim( $user_message . ' ' . $answer );
			$greped        = Flowbie_Wp_Harness_Links::grep_linkable_posts( $harness_items, $query, 8 );
			foreach ( $greped as $post ) {
				$item = self::from_harness_post( $post, $items );
				if ( null !== $item ) {
					self::add_link( $found, $order, $item, $site_url );
				}
			}

			if ( in_array( $intent, array( 'navigation', 'recommendation' ), true ) ) {
				foreach ( array_slice( $items, 0, 3 ) as $item ) {
					if ( ! empty( $item['url'] ) && ! empty( $item['title'] ) ) {
						self::add_link( $found, $order, $item, $site_url );
					}
				}
			}
		}

		$links = array();
		foreach ( $order as $norm ) {
			if ( isset( $found[ $norm ] ) ) {
				$links[] = $found[ $norm ];
			}
		}

		return self::filter_links_to_index( $links, $site_index );
	}

	/**
	 * Rank items by slug/title/URL match to the user message.
	 *
	 * @param array<int,array<string,mixed>> $items
	 * @return array<int,array{label:string,url:string,icon:string}>
	 */
	public static function pick_topic_links( string $user_message, array $items, int $limit = 3, array $site_index = array(), bool $strict = false, array $extra_phrases = array(), array $exclude_urls = array() ): array {
		$user_message = trim( $user_message );
		$pool         = ! empty( $site_index ) ? $site_index : $items;
		if ( $user_message === '' || empty( $pool ) ) {
			return array();
		}

		$exclude = array();
		foreach ( $exclude_urls as $url ) {
			$norm = Flowbie_Wp_Chat_History::normalize_url( (string) $url );
			if ( $norm !== '' ) {
				$exclude[ $norm ] = true;
			}
		}

		$fetch_limit = max( $limit * 8, 12 );
		$links       = array();
		foreach ( Flowbie_Wp_Chat_Rag::find_fuzzy_topic_pages( $user_message, $pool, $fetch_limit, $extra_phrases ) as $item ) {
			$norm = Flowbie_Wp_Chat_History::normalize_url( (string) ( $item['url'] ?? '' ) );
			if ( $norm === '' || isset( $exclude[ $norm ] ) ) {
				continue;
			}
			$phrases = self::anchor_phrases_for_item( $item );
			$label   = ! empty( $phrases[0] ) ? $phrases[0] : (string) ( $item['title'] ?? '' );
			if ( $label === '' ) {
				continue;
			}
			$links[] = array(
				'label' => ucwords( $label ),
				'url'   => (string) $item['url'],
				'icon'  => ( isset( $item['type'] ) && $item['type'] === 'post' ) ? 'post' : 'page',
				'score' => (float) ( $item['fuzzy_score'] ?? 0 ),
			);
			if ( count( $links ) >= $limit ) {
				break;
			}
		}

		return $links;
	}

	/**
	 * Best fuzzy-matched service/topic page for CTA.
	 *
	 * @param array<int,array<string,mixed>> $items
	 * @return array{label:string,url:string,icon:string,score:float}|null
	 */
	public static function pick_primary_topic_link( string $user_message, array $items, array $site_index = array(), array $extra_phrases = array(), array $exclude_urls = array() ): ?array {
		$links = self::pick_topic_links( $user_message, $items, 1, $site_index, true, $extra_phrases, $exclude_urls );
		return ! empty( $links ) ? $links[0] : null;
	}

	/**
	 * @param array<string,mixed> $classification
	 * @return array<int,string>
	 */
	private static function phrase_context( array $classification ): array {
		return isset( $classification['search_terms'] ) ? array_values( (array) $classification['search_terms'] ) : array();
	}

	/**
	 * @param array<int,array<string,mixed>> $pool
	 * @return array<int,array{item:array<string,mixed>,score:float}>
	 */
	private static function score_topic_pool( string $user_message, array $pool, bool $strict, array $extra_phrases = array() ): array {
		$scored = array();
		foreach ( $pool as $item ) {
			if ( empty( $item['url'] ) ) {
				continue;
			}
			$has_slug  = Flowbie_Wp_Chat_Rag::item_has_topic_slug_match( $user_message, $item, $extra_phrases );
			$term_hits = Flowbie_Wp_Chat_Rag::count_slug_path_term_hits( $user_message, $item, $extra_phrases );
			$score     = Flowbie_Wp_Chat_Rag::score_topic_match( $user_message, $item, $extra_phrases );

			if ( $strict ) {
				if ( ! $has_slug || $score <= 0 ) {
					continue;
				}
				if ( $term_hits < 2 && ! self::has_strong_single_slug_match( $user_message, $item, $extra_phrases ) ) {
					continue;
				}
			} elseif ( ! $has_slug && $score < 6.0 ) {
				continue;
			} elseif ( $score <= 0 ) {
				continue;
			}

			$scored[] = array(
				'item'  => $item,
				'score' => $score,
			);
		}

		if ( empty( $scored ) ) {
			return array();
		}

		usort(
			$scored,
			function ( $a, $b ) use ( $user_message, $extra_phrases ) {
				$score_cmp = ( $b['score'] ?? 0 ) <=> ( $a['score'] ?? 0 );
				if ( $score_cmp !== 0 ) {
					return $score_cmp;
				}
				return Flowbie_Wp_Chat_Rag::slug_focus_score( $user_message, $b['item'], $extra_phrases ) <=> Flowbie_Wp_Chat_Rag::slug_focus_score( $user_message, $a['item'], $extra_phrases );
			}
		);

		return $scored;
	}

	/**
	 * Single-segment procedure slugs (e.g. invisalign) qualify with one strong term hit.
	 *
	 * @param array<string,mixed> $item
	 */
	private static function has_strong_single_slug_match( string $user_message, array $item, array $extra_phrases = array() ): bool {
		$match_terms = Flowbie_Wp_Chat_Rag::extract_match_terms( $user_message, $extra_phrases );
		if ( empty( $match_terms ) ) {
			return false;
		}
		$slug = isset( $item['slug'] ) ? strtolower( (string) $item['slug'] ) : '';
		if ( $slug === '' && ! empty( $item['url'] ) ) {
			$path = wp_parse_url( (string) $item['url'], PHP_URL_PATH );
			if ( is_string( $path ) && $path !== '' ) {
				$slug = strtolower( trim( basename( untrailingslashit( $path ) ), '/' ) );
			}
		}
		if ( $slug === '' ) {
			return false;
		}
		foreach ( $match_terms as $term ) {
			if ( strlen( $term ) < 4 ) {
				continue;
			}
			if ( $slug === $term || strpos( $slug, $term ) !== false ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Natural anchor phrases from slug/title (longest first).
	 *
	 * @param array<string,mixed> $item
	 * @return array<int,string>
	 */
	public static function anchor_phrases_for_item( array $item ): array {
		$phrases = array();
		$slug    = isset( $item['slug'] ) ? trim( (string) $item['slug'] ) : '';

		if ( $slug === '' && ! empty( $item['url'] ) ) {
			$path = wp_parse_url( (string) $item['url'], PHP_URL_PATH );
			if ( is_string( $path ) && $path !== '' ) {
				$slug = trim( basename( untrailingslashit( $path ) ), '/' );
			}
		}

		if ( $slug !== '' ) {
			$phrases[] = str_replace( '-', ' ', $slug );
			$parts     = array_filter( explode( '-', $slug ) );
			if ( count( $parts ) >= 2 ) {
				$phrases[] = str_replace( '-', ' ', implode( '-', array_slice( $parts, -2 ) ) );
			}
			if ( count( $parts ) >= 1 ) {
				$phrases[] = str_replace( '-', ' ', end( $parts ) );
			}
		}

		if ( ! empty( $item['title'] ) ) {
			$title = trim( (string) $item['title'] );
			if ( $title !== '' ) {
				$phrases[] = $title;
			}
		}

		if ( ! empty( $item['focus_keyword'] ) ) {
			$kw = trim( (string) $item['focus_keyword'] );
			if ( $kw !== '' ) {
				$phrases[] = $kw;
			}
		}

		$unique = array();
		foreach ( $phrases as $phrase ) {
			$phrase = trim( preg_replace( '/\s+/', ' ', $phrase ) );
			if ( strlen( $phrase ) < 3 ) {
				continue;
			}
			$key = strtolower( $phrase );
			if ( ! isset( $unique[ $key ] ) ) {
				$unique[ $key ] = $phrase;
			}
		}

		$out = array_values( $unique );
		usort(
			$out,
			function ( $a, $b ) {
				return strlen( $b ) <=> strlen( $a );
			}
		);

		return $out;
	}

	/**
	 * Merge grep results into a card; set CTA and inline markdown links when missing.
	 *
	 * @param array<string,mixed>              $card
	 * @param array<int,array<string,mixed>>   $items
	 * @param array<string,mixed>              $classification
	 * @return array<string,mixed>
	 */
	public static function attach_to_card( array $card, string $user_message, string $answer, array $items, array $classification, array $site_index = array(), array $exclude_urls = array(), array $exclude_topics = array() ): array {
		$intent       = isset( $classification['intent'] ) ? (string) $classification['intent'] : 'question';
		$topic_intent = in_array( $intent, array( 'question', 'support' ), true );
		$phrases      = self::phrase_context( $classification );
		$site_url     = home_url( '/' );

		$lead_action = self::detect_lead_action( $user_message );
		$lead_pages  = $lead_action ? self::find_lead_pages( $user_message, $site_index, 3 ) : array();
		$lead_links  = self::items_to_links( $lead_pages );

		if ( $topic_intent ) {
			$link_pool    = self::dedupe_items_by_id( array_merge( $items, $lead_pages ) );
			if ( empty( $link_pool ) ) {
				$link_pool = $site_index;
			}
			$primary_link = self::pick_primary_topic_link( $user_message, $items, $link_pool, $phrases, $exclude_urls );
			$topic_links  = self::pick_topic_links( $user_message, $items, 2, $link_pool, true, $phrases, $exclude_urls );

			$primary_arr = array();
			if ( null !== $primary_link ) {
				$primary_arr[] = array(
					'label' => $primary_link['label'],
					'url'   => $primary_link['url'],
					'icon'  => isset( $primary_link['icon'] ) ? $primary_link['icon'] : 'page',
				);
			}

			$merged = self::merge_link_groups( $lead_links, $primary_arr, $topic_links );
			$merged = self::filter_links_to_index( $merged, $site_index );
			$merged = self::filter_excluded_urls( $merged, $exclude_urls );

			if ( ! empty( $merged ) ) {
				$card['links'] = array_slice( $merged, 0, 4 );
				$card['cta']   = array(
					'label' => $merged[0]['label'],
					'url'   => $merged[0]['url'],
				);

				if ( ! empty( $card['body'] ) ) {
					$inject_pool = ! empty( $site_index ) ? array_merge( $items, $site_index, $lead_pages ) : array_merge( $items, $lead_pages );
					if ( $lead_action && ! empty( $lead_links ) ) {
						$card['body'] = self::link_body_page_mentions( (string) $card['body'], $lead_pages, $lead_links );
						$card['body'] = self::inject_body_markdown_links( (string) $card['body'], $lead_links, $inject_pool );
					} else {
						if ( null !== $primary_link ) {
							$card['body'] = self::replace_non_topic_markdown_urls(
								(string) $card['body'],
								(string) $merged[0]['url'],
								$user_message,
								$items,
								$site_index,
								$phrases
							);
						}
						$card['body'] = self::inject_body_markdown_links( (string) $card['body'], $merged, $inject_pool );
					}
				}
			} else {
				unset( $card['cta'] );
				$card['links'] = array();
				if ( ! empty( $card['body'] ) ) {
					$card['body'] = self::strip_non_topic_markdown_urls(
						(string) $card['body'],
						$user_message,
						$items,
						$site_index,
						$phrases,
						$lead_pages
					);
				}
			}

			if ( ! empty( $card['body'] ) ) {
				$card['body'] = self::repair_malformed_markdown_links( (string) $card['body'] );
				$card['body'] = self::strip_bracket_citations( (string) $card['body'] );
			}

			return self::finalize_card_topics( $card, $user_message, $items, $site_index, $exclude_topics );
		}

		$greped   = self::grep_links_for_suggestion( $user_message, $answer, $items, $classification, $site_index );
		$existing = isset( $card['links'] ) && is_array( $card['links'] ) ? $card['links'] : array();
		$prefixed = self::merge_link_groups( $lead_links, $existing, $greped );
		$merged   = self::filter_links_to_index( self::merge_links( $prefixed, array(), $site_url ), $site_index );
		$merged   = self::filter_excluded_urls( $merged, $exclude_urls );

		$card['links'] = $merged;

		if ( ! ( is_array( $card['cta'] ?? null ) && ! empty( $card['cta']['url'] ) ) && ! empty( $merged ) && in_array( $intent, array( 'navigation', 'recommendation' ), true ) ) {
			$card['cta'] = array(
				'label' => $merged[0]['label'],
				'url'   => $merged[0]['url'],
			);
		} elseif ( is_array( $card['cta'] ?? null ) && ! empty( $card['cta']['url'] ) ) {
			$cta_allowed = self::filter_links_to_index( array( $card['cta'] ), $site_index );
			$cta_allowed = self::filter_excluded_urls( $cta_allowed, $exclude_urls );
			if ( empty( $cta_allowed ) ) {
				unset( $card['cta'] );
			}
		}

		if ( ! empty( $card['body'] ) && ! empty( $merged ) ) {
			$inject_pool = ! empty( $site_index ) ? array_merge( $items, $site_index, $lead_pages ) : array_merge( $items, $lead_pages );
			if ( $lead_action && ! empty( $lead_links ) ) {
				$card['body'] = self::link_body_page_mentions( (string) $card['body'], $lead_pages, $lead_links );
				$card['body'] = self::inject_body_markdown_links( (string) $card['body'], $lead_links, $inject_pool );
			} else {
				$card['body'] = self::inject_body_markdown_links( (string) $card['body'], $merged, $inject_pool );
				$card['body'] = self::link_body_page_mentions( (string) $card['body'], $lead_pages, $merged );
			}
		}

		if ( ! empty( $card['body'] ) ) {
			$card['body'] = self::repair_malformed_markdown_links( (string) $card['body'] );
			$card['body'] = self::strip_bracket_citations( (string) $card['body'] );
		}

		return self::finalize_card_topics( $card, $user_message, $items, $site_index, $exclude_topics );
	}

	/**
	 * Dedupe history chips then backfill to minimum follow-up count.
	 *
	 * @param array<string,mixed>          $card
	 * @param array<int,array<string,mixed>> $items
	 * @param array<int,array<string,mixed>> $site_index
	 * @param array<int,string>            $exclude_topics
	 * @return array<string,mixed>
	 */
	private static function finalize_card_topics( array $card, string $user_message, array $items, array $site_index, array $exclude_topics ): array {
		$card = self::apply_topic_dedupe( $card, $exclude_topics );
		return Flowbie_Wp_Chat_Agents::ensure_minimum_related_topics( $card, $user_message, $items, $site_index, $exclude_topics );
	}

	/**
	 * @param array<string,mixed> $card
	 * @param array<int,string>   $exclude_topics
	 * @return array<string,mixed>
	 */
	private static function apply_topic_dedupe( array $card, array $exclude_topics ): array {
		if ( empty( $card['relatedTopics'] ) || ! is_array( $card['relatedTopics'] ) || empty( $exclude_topics ) ) {
			return $card;
		}

		$filtered = Flowbie_Wp_Chat_History::filter_topics( $card['relatedTopics'], $exclude_topics );
		if ( empty( $filtered ) ) {
			unset( $card['relatedTopics'] );
		} else {
			$card['relatedTopics'] = $filtered;
		}

		return $card;
	}

	/**
	 * @param array<int,array{label:string,url:string,icon?:string}> $links
	 * @param array<int,string>                                      $exclude_urls
	 * @return array<int,array{label:string,url:string,icon?:string}>
	 */
	private static function filter_excluded_urls( array $links, array $exclude_urls ): array {
		if ( empty( $links ) || empty( $exclude_urls ) ) {
			return $links;
		}

		$exclude = array();
		foreach ( $exclude_urls as $url ) {
			$norm = Flowbie_Wp_Chat_History::normalize_url( (string) $url );
			if ( $norm !== '' ) {
				$exclude[ $norm ] = true;
			}
		}

		$out = array();
		foreach ( $links as $link ) {
			if ( ! is_array( $link ) || empty( $link['url'] ) ) {
				continue;
			}
			$norm = Flowbie_Wp_Chat_History::normalize_url( (string) $link['url'] );
			if ( $norm === '' || isset( $exclude[ $norm ] ) ) {
				continue;
			}
			$out[] = $link;
		}

		return $out;
	}

	private static function strip_bracket_citations( string $body ): string {
		$stripped = preg_replace( '/\s*\[\d+\]/', '', $body );
		return is_string( $stripped ) ? $stripped : $body;
	}

	/**
	 * @param array{label:string,url:string,icon?:string} $link
	 * @param array<int,array<string,mixed>>              $items
	 * @return array<string,mixed>
	 */
	private static function link_to_item( array $link, array $items, array $site_index = array() ): array {
		$url_norm = strtolower( rtrim( (string) $link['url'], '/' ) );
		$pools    = array_merge( $items, $site_index );
		foreach ( $pools as $item ) {
			if ( empty( $item['url'] ) ) {
				continue;
			}
			if ( strtolower( rtrim( (string) $item['url'], '/' ) ) === $url_norm ) {
				return $item;
			}
		}
		return array(
			'title' => isset( $link['label'] ) ? (string) $link['label'] : '',
			'url'   => (string) $link['url'],
			'type'  => ( isset( $link['icon'] ) && $link['icon'] === 'post' ) ? 'post' : 'page',
		);
	}

	private static function title_mentioned_in_text( string $title, string $text ): bool {
		$title = trim( $title );
		if ( $title === '' || $text === '' ) {
			return false;
		}
		return stripos( $text, $title ) !== false;
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 * @return array<int,array<string,mixed>>
	 */
	private static function to_harness_items( array $items ): array {
		$out = array();
		foreach ( $items as $item ) {
			if ( empty( $item['url'] ) ) {
				continue;
			}
			$slug = '';
			$path = wp_parse_url( (string) $item['url'], PHP_URL_PATH );
			if ( is_string( $path ) && $path !== '' ) {
				$slug = trim( basename( untrailingslashit( $path ) ), '/' );
			}
			$out[] = array(
				'id'      => isset( $item['id'] ) ? (int) $item['id'] : 0,
				'title'   => isset( $item['title'] ) ? (string) $item['title'] : '',
				'excerpt' => isset( $item['excerpt'] ) ? (string) $item['excerpt'] : '',
				'slug'    => $slug,
				'link'    => (string) $item['url'],
			);
		}
		return $out;
	}

	/**
	 * @param array<string,mixed>              $post
	 * @param array<int,array<string,mixed>>   $original_items
	 * @return array<string,mixed>|null
	 */
	private static function from_harness_post( array $post, array $original_items ): ?array {
		$link = isset( $post['link'] ) ? (string) $post['link'] : '';
		foreach ( $original_items as $item ) {
			if ( isset( $item['url'] ) && (string) $item['url'] === $link ) {
				return $item;
			}
		}
		if ( $link !== '' && ! empty( $post['title'] ) ) {
			return array(
				'id'    => isset( $post['id'] ) ? (int) $post['id'] : 0,
				'title' => (string) $post['title'],
				'url'   => $link,
				'type'  => 'page',
			);
		}
		return null;
	}

	/**
	 * @param array<string,array{label:string,url:string,icon:string}> $found
	 * @param array<int,string>                                        $order
	 * @param array<string,mixed>                                      $item
	 */
	private static function add_link( array &$found, array &$order, array $item, string $site_url ): void {
		$url = trim( (string) $item['url'] );
		if ( $url === '' ) {
			return;
		}
		$norm = Flowbie_Wp_Harness_Links::normalize_internal_url( $site_url, $url );
		if ( $norm === '' ) {
			$norm = strtolower( rtrim( $url, '/' ) );
		}
		if ( isset( $found[ $norm ] ) ) {
			return;
		}
		$found[ $norm ] = array(
			'label' => (string) $item['title'],
			'url'   => $url,
			'icon'  => ( isset( $item['type'] ) && $item['type'] === 'post' ) ? 'post' : 'page',
		);
		$order[]        = $norm;
	}

	/**
	 * @param array<int,array{label:string,url:string,icon?:string}> $existing
	 * @param array<int,array{label:string,url:string,icon:string}>  $greped
	 * @return array<int,array{label:string,url:string,icon:string}>
	 */
	private static function merge_links( array $existing, array $greped, string $site_url ): array {
		$found = array();
		$order = array();

		foreach ( $existing as $link ) {
			if ( ! is_array( $link ) || empty( $link['url'] ) ) {
				continue;
			}
			$item = array(
				'title' => isset( $link['label'] ) ? (string) $link['label'] : '',
				'url'   => (string) $link['url'],
				'type'  => ( isset( $link['icon'] ) && $link['icon'] === 'post' ) ? 'post' : 'page',
			);
			self::add_link( $found, $order, $item, $site_url );
			$norm = end( $order );
			if ( is_string( $norm ) && isset( $found[ $norm ] ) ) {
				if ( ! empty( $link['label'] ) ) {
					$found[ $norm ]['label'] = (string) $link['label'];
				}
				if ( ! empty( $link['icon'] ) ) {
					$found[ $norm ]['icon'] = (string) $link['icon'];
				}
			}
		}

		foreach ( $greped as $link ) {
			$item = array(
				'title' => $link['label'],
				'url'   => $link['url'],
				'type'  => ( isset( $link['icon'] ) && $link['icon'] === 'post' ) ? 'post' : 'page',
			);
			self::add_link( $found, $order, $item, $site_url );
		}

		$merged = array();
		foreach ( $order as $norm ) {
			if ( isset( $found[ $norm ] ) ) {
				$merged[] = $found[ $norm ];
			}
		}
		return $merged;
	}

	/**
	 * @param array<int,array{label:string,url:string,icon:string}> $links
	 * @param array<int,array<string,mixed>>                         $items
	 */
	private static function inject_body_markdown_links( string $body, array $links, array $items = array() ): string {
		$item_by_url = array();
		foreach ( $items as $item ) {
			if ( empty( $item['url'] ) ) {
				continue;
			}
			$norm = strtolower( rtrim( (string) $item['url'], '/' ) );
			$item_by_url[ $norm ] = $item;
		}

		foreach ( $links as $link ) {
			if ( empty( $link['url'] ) ) {
				continue;
			}
			$url  = (string) $link['url'];
			$norm = strtolower( rtrim( $url, '/' ) );
			$item = isset( $item_by_url[ $norm ] ) ? $item_by_url[ $norm ] : array(
				'title' => isset( $link['label'] ) ? (string) $link['label'] : '',
				'url'   => $url,
				'slug'  => '',
			);

			$phrases = self::anchor_phrases_for_item( $item );
			if ( empty( $phrases ) && ! empty( $link['label'] ) ) {
				$phrases = array( (string) $link['label'] );
			}

			foreach ( $phrases as $phrase ) {
				if ( self::body_has_markdown_link_for_phrase( $body, $phrase ) ) {
					break;
				}
				$linked = self::link_first_phrase( $body, $phrase, $url );
				if ( $linked !== $body ) {
					$body = $linked;
					break;
				}
			}
		}

		return $body;
	}

	/**
	 * Rewrite inline markdown links that point at off-topic pages to the primary topic URL.
	 */
	private static function replace_non_topic_markdown_urls( string $body, string $primary_url, string $user_message, array $items, array $site_index, array $extra_phrases = array() ): string {
		$primary_norm = strtolower( rtrim( $primary_url, '/' ) );
		$replaced     = preg_replace_callback(
			'/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/i',
			function ( array $matches ) use ( $primary_norm, $primary_url, $user_message, $items, $site_index, $extra_phrases ) {
				$url_norm = strtolower( rtrim( $matches[2], '/' ) );
				if ( $url_norm === $primary_norm ) {
					return $matches[0];
				}
				$item = self::link_to_item(
					array(
						'label' => $matches[1],
						'url'   => $matches[2],
					),
					$items,
					$site_index
				);
				if (
					Flowbie_Wp_Chat_Rag::item_has_topic_slug_match( $user_message, $item, $extra_phrases )
					&& (
						Flowbie_Wp_Chat_Rag::count_slug_path_term_hits( $user_message, $item, $extra_phrases ) >= 2
						|| self::has_strong_single_slug_match( $user_message, $item, $extra_phrases )
					)
				) {
					return $matches[0];
				}
				return '[' . $matches[1] . '](' . $primary_url . ')';
			},
			$body
		);
		return is_string( $replaced ) ? $replaced : $body;
	}

	/**
	 * Link plain-text page mentions in the body (e.g. "contact us page") when no markdown link exists yet.
	 *
	 * @param array<int,array<string,mixed>>                         $lead_pages
	 * @param array<int,array{label:string,url:string,icon:string}> $links
	 */
	private static function link_body_page_mentions( string $body, array $lead_pages, array $links ): string {
		if ( $body === '' || empty( $links ) ) {
			return $body;
		}

		$phrases = array(
			'contact us page',
			'contact page',
			'contact us',
			'book an appointment',
			'book a consultation',
			'schedule a consultation',
			'get a quote',
			'request a quote',
		);

		foreach ( $lead_pages as $item ) {
			$title = trim( wp_strip_all_tags( (string) ( $item['title'] ?? '' ) ) );
			if ( $title !== '' ) {
				$phrases[] = strtolower( $title );
			}
		}

		foreach ( $links as $link ) {
			if ( empty( $link['url'] ) ) {
				continue;
			}
			$url = (string) $link['url'];
			if ( ! empty( $link['label'] ) ) {
				$phrases[] = strtolower( (string) $link['label'] );
			}
			foreach ( $phrases as $phrase ) {
				if ( self::body_has_markdown_link_for_phrase( $body, $phrase ) ) {
					break;
				}
				$linked = self::link_first_phrase( $body, $phrase, $url );
				if ( $linked !== $body ) {
					$body = $linked;
					break;
				}
			}
		}

		return $body;
	}

	/**
	 * Remove inline markdown links that are not slug/path matched (no substitute URL).
	 *
	 * @param array<int,array<string,mixed>> $lead_pages Lead page items whose URLs are preserved.
	 */
	private static function strip_non_topic_markdown_urls( string $body, string $user_message, array $items, array $site_index, array $extra_phrases = array(), array $lead_pages = array() ): string {
		$lead_url_norms = array();
		foreach ( $lead_pages as $page ) {
			if ( empty( $page['url'] ) ) {
				continue;
			}
			$lead_url_norms[ strtolower( rtrim( (string) $page['url'], '/' ) ) ] = true;
		}

		$replaced = preg_replace_callback(
			'/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/i',
			function ( array $matches ) use ( $user_message, $items, $site_index, $extra_phrases, $lead_url_norms ) {
				$url_norm = strtolower( rtrim( $matches[2], '/' ) );
				if ( isset( $lead_url_norms[ $url_norm ] ) ) {
					return $matches[0];
				}
				$item = self::link_to_item(
					array(
						'label' => $matches[1],
						'url'   => $matches[2],
					),
					$items,
					$site_index
				);
				if (
					Flowbie_Wp_Chat_Rag::item_has_topic_slug_match( $user_message, $item, $extra_phrases )
					&& (
						Flowbie_Wp_Chat_Rag::count_slug_path_term_hits( $user_message, $item, $extra_phrases ) >= 2
						|| self::has_strong_single_slug_match( $user_message, $item, $extra_phrases )
					)
				) {
					return $matches[0];
				}
				return $matches[1];
			},
			$body
		);
		return is_string( $replaced ) ? $replaced : $body;
	}

	private static function body_contains_url( string $body, string $url ): bool {
		return stripos( $body, $url ) !== false;
	}

	/**
	 * Normalize corrupted inline markdown produced by double-wrapping.
	 */
	public static function repair_malformed_markdown_links( string $body ): string {
		if ( $body === '' ) {
			return $body;
		}

		$repaired = preg_replace(
			'/\[\[([^\]]+)\]\((https?:\/\/[^)]+)\)\]\((https?:\/\/[^)]+)\)/i',
			'[$1]($2)',
			$body
		);
		if ( ! is_string( $repaired ) ) {
			return $body;
		}

		$repaired = preg_replace(
			'/\[([^\]]+)\]\((https?:\/\/[^)]+)\)\]\((https?:\/\/[^)]+)\)/i',
			'[$1]($2)',
			$repaired
		);

		return is_string( $repaired ) ? $repaired : $body;
	}

	private static function body_has_markdown_link_for_phrase( string $body, string $phrase ): bool {
		$phrase = trim( $phrase );
		if ( $phrase === '' ) {
			return false;
		}

		if ( preg_match_all( '/\[([^\]]*)\]\((https?:\/\/[^)]+)\)/i', $body, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				$label = trim( (string) $match[1] );
				if ( strcasecmp( $label, $phrase ) === 0 ) {
					return true;
				}
				if ( $label !== '' && stripos( $label, $phrase ) !== false ) {
					return true;
				}
			}
		}

		return false;
	}

	private static function link_first_phrase( string $body, string $phrase, string $url ): string {
		$phrase = trim( $phrase );
		if ( $phrase === '' || strlen( $phrase ) < 3 ) {
			return $body;
		}

		if ( self::body_has_markdown_link_for_phrase( $body, $phrase ) ) {
			return $body;
		}

		$offset     = 0;
		$lower      = strtolower( $body );
		$needle     = strtolower( $phrase );
		$needle_len = strlen( $needle );

		while ( $offset < strlen( $body ) ) {
			$pos = strpos( $lower, $needle, $offset );
			if ( $pos === false ) {
				break;
			}
			if ( ! self::phrase_overlaps_markdown_link( $body, $pos, $pos + $needle_len ) ) {
				$matched = substr( $body, $pos, $needle_len );
				$body    = substr( $body, 0, $pos ) . '[' . $matched . '](' . $url . ')' . substr( $body, $pos + $needle_len );
				return $body;
			}
			$offset = $pos + $needle_len;
		}

		return $body;
	}

	private static function phrase_overlaps_markdown_link( string $body, int $start, int $end ): bool {
		$before = substr( $body, 0, $start );
		$open   = strrpos( $before, '[' );
		if ( $open !== false ) {
			$close_bracket = strpos( $body, ']', $open );
			if (
				$close_bracket !== false
				&& $start >= $open + 1
				&& $end <= $close_bracket
				&& $close_bracket + 2 <= strlen( $body )
				&& substr( $body, $close_bracket, 2 ) === ']('
			) {
				return true;
			}
		}

		$offset = 0;
		while ( preg_match( '/\[([^\]]*)\]\((https?:\/\/[^)]+)\)/', $body, $match, PREG_OFFSET_CAPTURE, $offset ) ) {
			$full_start = (int) $match[0][1];
			$full_end   = $full_start + strlen( $match[0][0] );
			if ( $start < $full_end && $end > $full_start ) {
				return true;
			}
			$offset = $full_end;
		}

		return false;
	}

	private static function phrase_inside_markdown_link( string $body, int $start, int $end ): bool {
		return self::phrase_overlaps_markdown_link( $body, $start, $end );
	}
}
