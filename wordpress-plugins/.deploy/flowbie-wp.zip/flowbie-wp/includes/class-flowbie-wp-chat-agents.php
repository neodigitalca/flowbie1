<?php
/**
 * Three-phase sub-agent orchestration for the Flowbie Chat widget.
 *
 * Phase A: Classify intent + select relevant content (fast model).
 * Phase B: Reason and draft an answer (capable model).
 * Phase C: Format the answer as a semantic card JSON (fast model).
 *
 * @package Flowbie_Wp
 */

defined( 'ABSPATH' ) || exit;

class Flowbie_Wp_Chat_Agents {

	const FAST_MODEL              = 'google/gemini-2.5-flash-lite';
	const REASON_MODEL            = 'google/gemini-2.5-flash';
	const FAST_PATH_SCORE         = 8.0;
	const NARROW_INVENTORY_LIMIT  = 30;
	const MIN_RELATED_TOPICS      = 2;
	const MAX_RELATED_TOPICS      = 4;

	/**
	 * Run the full three-phase pipeline.
	 *
	 * @param string $user_message  Current user message.
	 * @param array  $history       Conversation history [{role,content},...].
	 * @param string $site_name     Human-readable site name.
	 * @param array  $site_index    Full site inventory from RAG.
	 * @param array  $training      Training settings (assistant_name, system_prompt, greeting_style, knowledge_base).
	 * @return array Semantic card JSON or error shape.
	 */
	public static function run( string $user_message, array $history, string $site_name, array $site_index, array $training = array(), array $chat_settings = array() ): array {
		$gate = self::phase_ack( $user_message, $site_name, array(), $training, $history );
		if ( is_wp_error( $gate ) ) {
			return self::error_card( $gate->get_error_message() );
		}
		if ( is_array( $gate ) && ( $gate['action'] ?? '' ) === 'deny' ) {
			return self::build_denial_card( (string) ( $gate['text'] ?? '' ), $user_message, $site_name, $site_index, $history );
		}

		$phase_a = self::phase_classify( $user_message, $site_name, $site_index );
		if ( is_wp_error( $phase_a ) ) {
			return self::error_card( $phase_a->get_error_message() );
		}

		$relevant_items = self::select_relevant_items( $phase_a, $site_index, $user_message, $chat_settings );
		$relevant_items = Flowbie_Wp_Chat::enrich_relevant_items( $relevant_items, false, $chat_settings );

		$phase_b = self::phase_reason( $user_message, $history, $site_name, $relevant_items, $phase_a, $training, $site_index );
		if ( is_wp_error( $phase_b ) ) {
			return self::error_card( $phase_b->get_error_message() );
		}

		$phase_c = self::phase_format( $phase_b, $phase_a, $relevant_items );
		if ( is_wp_error( $phase_c ) ) {
			return self::fallback_card( $phase_b, $relevant_items, $user_message, $phase_a, $site_index, $history );
		}

		$seen_urls   = Flowbie_Wp_Chat_History::collect_seen_urls( $history );
		$seen_topics = Flowbie_Wp_Chat_History::collect_seen_topics( $history );

		return Flowbie_Wp_Chat_Links::attach_to_card( $phase_c, $user_message, $phase_b, $relevant_items, $phase_a, $site_index, $seen_urls, $seen_topics );
	}

	/**
	 * Secretary gate: brief ack or deny before content lookup (stream + run paths).
	 *
	 * @param array<string,mixed> $training Assistant name + tone settings.
	 * @return array{action:string,text:string}|WP_Error action is continue|deny
	 */
	public static function phase_ack( string $message, string $site_name, array $retrieved = array(), array $training = array(), array $history = array() ) {
		$assistant = isset( $training['assistant_name'] ) && $training['assistant_name'] !== ''
			? (string) $training['assistant_name']
			: 'Flow Assist';

		$greeting_style = isset( $training['greeting_style'] ) ? (string) $training['greeting_style'] : 'friendly';
		$tone_map       = array(
			'professional' => 'Warm but polished, like a receptionist at a design showroom.',
			'friendly'     => 'Casual and approachable, like a helpful teammate in chat.',
			'casual'       => 'Relaxed and conversational, like texting a knowledgeable friend.',
		);
		$tone = isset( $tone_map[ $greeting_style ] ) ? $tone_map[ $greeting_style ] : $tone_map['friendly'];

		$recent_user = array();
		foreach ( array_slice( $history, -4 ) as $entry ) {
			if ( ! is_array( $entry ) || ( $entry['role'] ?? '' ) !== 'user' ) {
				continue;
			}
			$content = trim( (string) ( $entry['content'] ?? '' ) );
			if ( $content !== '' ) {
				$recent_user[] = $content;
			}
		}
		$context_block = '';
		if ( ! empty( $recent_user ) ) {
			$context_block = "Recent visitor messages:\n- " . implode( "\n- ", $recent_user ) . "\n";
		}

		$system = <<<PROMPT
You are {$assistant} at {$site_name}.
The visitor just sent a chat message. Output ONLY valid JSON:
{"action":"continue","text":"..."}
or
{"action":"deny","text":"..."}

Tone: {$tone}

Set "action" to "deny" when the message is:
- Illegal, harmful, violent, explicit, or asks for wrongdoing
- Clearly unrelated to {$site_name} and its business (not a plausible visitor question)
- Bad-faith or troll with no real intent to learn about the site

Set "action" to "continue" for normal questions about this site's products, services, locations, booking, pricing, repairs, and similar visitor topics.

For "continue": "text" is 6-12 words acknowledging their topic naturally. Do not answer the question. Do not say you are looking anything up.

For "deny": "text" is 6-12 words politely refusing. Do not echo or engage with the off-topic subject.

Output only JSON. No markdown fences. No emoji.
PROMPT;

		$user = trim( "Visitor message: \"{$message}\"\n{$context_block}" );

		$result = self::call_openrouter( self::FAST_MODEL, $system, $user, 128, 0.3 );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return self::normalize_gate_response( $result );
	}

	/**
	 * Card for denied secretary gate (no RAG / Phase B).
	 *
	 * @param array<int,array<string,mixed>> $site_index
	 * @return array<string,mixed>
	 */
	public static function build_denial_card( string $ack_text, string $user_message, string $site_name, array $site_index, array $history = array() ): array {
		$title = trim( $ack_text ) !== '' ? trim( $ack_text ) : 'I cannot help with that.';
		$body  = 'I can only help with questions about ' . $site_name . '. Ask me about our products or services.';

		$card = array(
			'type'       => 'answer',
			'title'      => $title,
			'body'       => $body,
			'links'      => array(),
			'confidence' => 'high',
		);

		$classification = array(
			'intent'       => 'question',
			'search_terms' => array(),
		);

		$seen_urls   = Flowbie_Wp_Chat_History::collect_seen_urls( $history );
		$seen_topics = Flowbie_Wp_Chat_History::collect_seen_topics( $history );

		return Flowbie_Wp_Chat_Links::attach_to_card( $card, $user_message, $body, array(), $classification, $site_index, $seen_urls, $seen_topics );
	}

	/**
	 * @return array{action:string,text:string}
	 */
	private static function normalize_gate_response( string $raw ): array {
		$parsed = self::parse_json_response( $raw );
		if ( is_array( $parsed ) && isset( $parsed['action'], $parsed['text'] ) ) {
			$action = (string) $parsed['action'] === 'deny' ? 'deny' : 'continue';
			$text   = self::sanitize_ack_text( (string) $parsed['text'] );
			if ( $text !== '' ) {
				return array(
					'action' => $action,
					'text'   => $text,
				);
			}
		}

		$text = self::sanitize_ack_text( $raw );
		return array(
			'action' => 'continue',
			'text'   => $text,
		);
	}

	/**
	 * Trim model ack output to a single human line.
	 */
	private static function sanitize_ack_text( string $text ): string {
		$text = trim( $text );
		$text = trim( $text, "\"'“”‘’" );
		$text = preg_replace( '/\s+/', ' ', $text );
		if ( $text === '' ) {
			return '';
		}
		if ( ! preg_match( '/[.!?]$/', $text ) ) {
			$text .= '.';
		}
		return $text;
	}

	/**
	 * Synthesize Phase A from high-confidence keyword retrieval (skip LLM classify).
	 *
	 * @param array<int,array<string,mixed>> $retrieved
	 * @return array|null
	 */
	public static function synthesize_classification_from_retrieve( string $message, array $retrieved ): ?array {
		if ( empty( $retrieved ) ) {
			return null;
		}

		$top = $retrieved[0];
		$score = (float) ( $top['score'] ?? 0 );
		if ( $score < self::FAST_PATH_SCORE ) {
			return null;
		}

		$slug_hits = Flowbie_Wp_Chat_Rag::count_slug_path_term_hits( $message, $top );
		if ( $slug_hits < 1 ) {
			return null;
		}

		$ids = array();
		$terms = Flowbie_Wp_Chat_Rag::extract_terms( $message );
		foreach ( $retrieved as $item ) {
			$item_score = (float) ( $item['score'] ?? 0 );
			if ( $item_score < self::FAST_PATH_SCORE * 0.5 ) {
				continue;
			}
			$ids[] = (int) $item['id'];
			if ( count( $ids ) >= Flowbie_Wp_Chat_Rag::MAX_RESULTS ) {
				break;
			}
		}

		return array(
			'intent'       => Flowbie_Wp_Chat_Links::detect_lead_action( $message ) ? 'navigation' : 'question',
			'relevant_ids' => $ids,
			'search_terms' => array_values( $terms ),
		);
	}

	/**
	 * Build narrowed candidate list for Phase A from instant retrieval.
	 *
	 * @param array<int,array<string,mixed>> $site_index
	 * @param array<int,array<string,mixed>> $retrieved
	 * @return array<int,array<string,mixed>>
	 */
	public static function build_narrow_candidate_items( array $site_index, string $message, array $retrieved, array $chat_settings = array() ): array {
		$by_id = array();
		foreach ( $retrieved as $item ) {
			if ( isset( $item['id'] ) ) {
				$by_id[ (int) $item['id'] ] = $item;
			}
		}
		foreach ( Flowbie_Wp_Chat_Rag::find_fuzzy_topic_pages( $message, $site_index, 10 ) as $item ) {
			$id = (int) ( $item['id'] ?? 0 );
			if ( $id > 0 && ! isset( $by_id[ $id ] ) ) {
				$by_id[ $id ] = $item;
			}
		}
		if ( empty( $by_id ) && ! empty( $retrieved ) ) {
			foreach ( $retrieved as $item ) {
				$by_id[ (int) $item['id'] ] = $item;
			}
		}
		if ( empty( $by_id ) ) {
			return array_slice( $site_index, 0, self::NARROW_INVENTORY_LIMIT );
		}

		$items = array_values( $by_id );
		usort(
			$items,
			function ( $a, $b ) use ( $message ) {
				$sa = isset( $a['score'] ) ? (float) $a['score'] : Flowbie_Wp_Chat_Rag::score_message_item( $message, $a );
				$sb = isset( $b['score'] ) ? (float) $b['score'] : Flowbie_Wp_Chat_Rag::score_message_item( $message, $b );
				return $sb <=> $sa;
			}
		);

		return array_slice( $items, 0, self::NARROW_INVENTORY_LIMIT );
	}

	/**
	 * Deterministic card shell from Phase B answer (stream path, skips Phase C LLM).
	 *
	 * @param array<int,array<string,mixed>> $items
	 * @param array<int,array<string,mixed>> $site_index
	 * @return array
	 */
	public static function build_card_from_answer( string $answer, array $classification, array $items, string $user_message, array $site_index, array $history = array() ): array {
		$intent    = isset( $classification['intent'] ) ? (string) $classification['intent'] : 'question';
		$card_type = Flowbie_Wp_Chat_Links::detect_lead_action( $user_message ) ? 'navigation' : self::intent_to_card_type( $intent );
		$split     = self::split_answer_title_body( $answer );
		$title     = $split['title'];
		$body      = $split['body'];

		$extra     = isset( $classification['search_terms'] ) ? array_values( (array) $classification['search_terms'] ) : array();
		$link_pool = ! empty( $items ) ? $items : $site_index;
		$topics    = Flowbie_Wp_Chat_Links::pick_topic_links( $user_message, $items, 6, $link_pool, false, $extra );
		$related   = array();
		foreach ( $topics as $link ) {
			$label = isset( $link['label'] ) ? trim( (string) $link['label'] ) : '';
			if ( $label === '' ) {
				continue;
			}
			$candidate = 'Tell me about ' . $label;
			if ( self::topic_matches_user_message( $candidate, $user_message ) ) {
				continue;
			}
			$related[] = $candidate;
			if ( count( $related ) >= 6 ) {
				break;
			}
		}

		$card = array(
			'type'          => $card_type,
			'title'         => $title,
			'body'          => $body,
			'links'         => array(),
			'confidence'    => 'high',
			'relatedTopics' => $related,
		);

		$seen_urls   = Flowbie_Wp_Chat_History::collect_seen_urls( $history );
		$seen_topics = Flowbie_Wp_Chat_History::collect_seen_topics( $history );

		return Flowbie_Wp_Chat_Links::attach_to_card( $card, $user_message, $body !== '' ? $body : $answer, $items, $classification, $site_index, $seen_urls, $seen_topics );
	}

	/**
	 * Phase A: classify intent and select relevant post IDs.
	 *
	 * @param array<int,array<string,mixed>>|null $candidate_items Narrow inventory subset; full index when null.
	 * @return array|WP_Error Parsed JSON with intent + relevant_ids.
	 */
	public static function phase_classify( string $message, string $site_name, array $site_index, ?array $candidate_items = null ) {
		$inventory_source = ( null !== $candidate_items && ! empty( $candidate_items ) ) ? $candidate_items : $site_index;
		$inventory_summary = self::build_inventory_summary( $inventory_source );

		$system = <<<PROMPT
You are a classification agent for the website "{$site_name}".
Given a user message and a list of site pages, output ONLY valid JSON with these fields:
- "intent": one of "question", "navigation", "recommendation", "support"
- "relevant_ids": array of up to 8 post IDs most relevant to the query (integers)
- "search_terms": array of key terms extracted from the query

INTENT RULES:
- Messages about booking, appointments, scheduling, consultation, contact, phone, quote, or pricing should use "intent": "navigation"

SITE CONTENT:
{$inventory_summary}
PROMPT;

		$result = self::call_openrouter( self::FAST_MODEL, $system, $message, 1024, 0.2 );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$parsed = self::parse_json_response( $result );
		if ( null === $parsed ) {
			return array(
				'intent'       => 'question',
				'relevant_ids' => array(),
				'search_terms' => array(),
			);
		}

		return $parsed;
	}

	/**
	 * Phase B: reason and draft an answer with full context.
	 *
	 * @return string|WP_Error The drafted answer text.
	 */
	public static function phase_reason( string $message, array $history, string $site_name, array $items, array $classification, array $training = array(), array $site_index = array() ) {
		$knowledge_base = isset( $training['knowledge_base'] ) && is_array( $training['knowledge_base'] ) ? $training['knowledge_base'] : array();
		$context        = Flowbie_Wp_Chat_Rag::format_context( $items, $knowledge_base );
		$links_block    = Flowbie_Wp_Chat_Links::build_links_context_block_for_reason( $message, $items, $site_index );
		$intent         = isset( $classification['intent'] ) ? $classification['intent'] : 'question';
		$lead_action    = Flowbie_Wp_Chat_Links::detect_lead_action( $message );
		$lead_rule      = ( $lead_action || $intent === 'navigation' )
			? "- User wants to take action. Lead with the real page URL from LINKS AVAILABLE in the first sentence as an inline markdown link. Name the page naturally (Book a consultation, Contact us, Get a quote).\n"
			: '';

		$assistant_name = isset( $training['assistant_name'] ) && $training['assistant_name'] !== '' ? $training['assistant_name'] : 'Flow Assist';
		$custom_prompt  = isset( $training['system_prompt'] ) && $training['system_prompt'] !== '' ? $training['system_prompt'] : '';
		$greeting_style = isset( $training['greeting_style'] ) ? $training['greeting_style'] : 'friendly';

		$tone_map = array(
			'professional' => 'Use a polished, professional tone. Be precise and authoritative.',
			'friendly'     => 'Use a warm, friendly tone. Be approachable and helpful.',
			'casual'       => 'Use a casual, relaxed tone. Be conversational and easygoing.',
		);
		$tone_instruction = isset( $tone_map[ $greeting_style ] ) ? $tone_map[ $greeting_style ] : $tone_map['friendly'];

		$history_text = Flowbie_Wp_Chat_History::format_for_prompt( $history );

		$identity = "You are \"{$assistant_name}\", the AI assistant for the website \"{$site_name}\".";
		if ( $custom_prompt !== '' ) {
			$identity .= "\n\nCUSTOM INSTRUCTIONS FROM SITE OWNER:\n{$custom_prompt}";
		}

		$system = <<<PROMPT
{$identity}
The user's intent is: {$intent}.

TONE: {$tone_instruction}

RULES:
- Lead with a direct answer to the user's question in the first 1-2 sentences.
{$lead_rule}- First synthesize from SITE CONTENT and HIGH PRIORITY knowledge base. Use those as the primary source whenever they contain relevant facts.
- When SITE CONTENT includes a page whose slug, URL, or title matches the topic, use that page's body as the main source for your answer.
- Only after using SITE CONTENT, add standard professional knowledge for parts the site copy does not cover.
- Use ALL SITE CONTENT blocks provided. Combine information from every matched page.
- Never refuse, defer, or replace an answer with "read this page instead." Links supplement the answer; they do not replace it.
- Do not use these phrases: "doesn't explicitly", "provided information", "while I don't have", "I can't find", "refer to the following resources", or "contact us" unless the user asked how to reach the office.
- Knowledge base entries marked HIGH PRIORITY should be used verbatim when they match the question.
- Weave at least one inline markdown link [natural phrase](url) from LINKS AVAILABLE using prose anchor text derived from the topic (not the full page title).
- When LINKS AVAILABLE includes a slug-matched service page for the question topic, use that page's URL for the inline link, not a broader blog post.
- Do not use bracket citation numbers such as [1] or [2] in the answer.
- If the user asks for a link or URL, include the real URL from the content.
- Do not repeat CTAs or source links already shown in this conversation unless the user explicitly asks for that page again.
- Follow-ups on the same topic should go deeper (timing, cost, recovery), not re-introduce the same landing page.
- Do not repeat prior suggestion chips verbatim.
- Be concise and helpful.
- When referencing pages, always include their URL.

SITE CONTENT:
{$context}

LINKS AVAILABLE:
{$links_block}

CONVERSATION HISTORY:
{$history_text}
PROMPT;

		return self::call_openrouter( self::REASON_MODEL, $system, $message, 2048, 0.5 );
	}

	/**
	 * Phase C: format the drafted answer as a semantic card JSON.
	 *
	 * @return array|WP_Error Parsed card JSON.
	 */
	public static function phase_format( string $answer, array $classification, array $items = array() ) {
		$intent = isset( $classification['intent'] ) ? $classification['intent'] : 'question';
		$type_map = array(
			'question'       => 'answer',
			'navigation'     => 'navigation',
			'recommendation' => 'recommendation',
			'support'        => 'answer',
		);
		$card_type = isset( $type_map[ $intent ] ) ? $type_map[ $intent ] : 'answer';

		$links_block = Flowbie_Wp_Chat_Links::build_links_context_block( $items );
		$links_hint  = $links_block !== '' ? "\n\nLINKS AVAILABLE:\n{$links_block}" : '';

		$system = <<<PROMPT
Convert the following assistant answer into ONLY valid JSON matching this exact schema:
{
  "type": "{$card_type}",
  "title": "short bold summary of the answer",
  "body": "the full answer text, supports markdown",
  "links": [{"label": "display text", "url": "https://...", "icon": "page|post|external"}],
  "cta": {"label": "button text", "url": "https://..."},
  "relatedTopics": ["topic 1", "topic 2"],
  "confidence": "high|medium|low"
}

Rules:
- "body" must contain the direct answer from the draft. Do not rewrite into a refusal or a links-only response.
- Preserve inline markdown links from the draft in "body".
- Do not include bracket citation numbers such as [1] or [2] in "body".
- Do not add hedge language not present in the draft.
- "links" must include every page URL from LINKS AVAILABLE that the answer suggests. Set icon to "page" for site pages, "post" for blog posts, "external" for outside links.
- "cta" should be the most specific slug-matched service or topic page from LINKS AVAILABLE when the question is about a service, procedure, or topic; otherwise omit and leave "cta" empty for the attach layer to fill. Do not set "cta" to a page whose slug or title does not match the user's question topic.
- "relatedTopics" MUST contain at least 2 items and at most 4 short suggested follow-up questions.
- "confidence" is "high" when the body directly answers the question, "medium" if partial, "low" only if the draft is mostly uncertain.
- Output ONLY the JSON object, no markdown fences, no explanation.{$links_hint}
PROMPT;

		$result = self::call_openrouter( self::FAST_MODEL, $system, $answer, 2048, 0.1 );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$parsed = self::parse_json_response( $result );
		if ( null === $parsed || ! isset( $parsed['title'] ) ) {
			return new WP_Error( 'flowbie_chat_format', 'Failed to format response as card.' );
		}

		$parsed['type'] = isset( $parsed['type'] ) ? $parsed['type'] : $card_type;
		$parsed['confidence'] = isset( $parsed['confidence'] ) ? $parsed['confidence'] : 'medium';

		return $parsed;
	}

	/**
	 * Merge Phase A ID picks with keyword retrieval on the user message.
	 */
	public static function select_relevant_items( array $classification, array $site_index, string $user_message = '', array $chat_settings = array() ): array {
		$merged = array();
		$scores = array();

		$ids = isset( $classification['relevant_ids'] ) ? array_map( 'intval', (array) $classification['relevant_ids'] ) : array();
		if ( ! empty( $ids ) ) {
			$id_set = array_flip( $ids );
			foreach ( $site_index as $item ) {
				if ( isset( $id_set[ $item['id'] ] ) ) {
					$id                = (int) $item['id'];
					$merged[ $id ]     = $item;
					$scores[ $id ]     = ( $scores[ $id ] ?? 0 ) + 10.0;
				}
			}
		}

		$query = trim( $user_message );
		if ( $query === '' && ! empty( $classification['search_terms'] ) ) {
			$query = implode( ' ', (array) $classification['search_terms'] );
		}
		if ( $query !== '' ) {
			foreach ( Flowbie_Wp_Chat_Rag::retrieve( $query, Flowbie_Wp_Chat_Rag::MAX_RESULTS, $chat_settings ) as $item ) {
				$id            = (int) $item['id'];
				$merged[ $id ] = isset( $merged[ $id ] ) ? array_merge( $merged[ $id ], $item ) : $item;
				$scores[ $id ] = ( $scores[ $id ] ?? 0 ) + (float) ( $item['score'] ?? 0 );
			}
		}

		if ( Flowbie_Wp_Chat_Links::detect_lead_action( $user_message ) ) {
			foreach ( Flowbie_Wp_Chat_Links::find_lead_pages( $user_message, $site_index, 3 ) as $item ) {
				$id            = (int) $item['id'];
				$merged[ $id ] = isset( $merged[ $id ] ) ? array_merge( $merged[ $id ], $item ) : $item;
				$scores[ $id ] = ( $scores[ $id ] ?? 0 ) + 15.0;
			}
		}

		if ( empty( $merged ) ) {
			return array();
		}

		arsort( $scores, SORT_NUMERIC );
		$ordered = array();
		foreach ( array_keys( $scores ) as $id ) {
			if ( isset( $merged[ $id ] ) ) {
				$ordered[] = $merged[ $id ];
			}
		}

		$ordered = array_slice( $ordered, 0, Flowbie_Wp_Chat_Rag::MAX_RESULTS );
		$extra   = isset( $classification['search_terms'] ) ? array_values( (array) $classification['search_terms'] ) : array();
		return Flowbie_Wp_Chat_Rag::ensure_topic_pages_in_items( $user_message, $ordered, $site_index, 3, $extra );
	}

	/**
	 * Map classify intent to semantic card type.
	 */
	private static function intent_to_card_type( string $intent ): string {
		$type_map = array(
			'question'       => 'answer',
			'navigation'     => 'navigation',
			'recommendation' => 'recommendation',
			'support'        => 'answer',
		);
		return isset( $type_map[ $intent ] ) ? $type_map[ $intent ] : 'answer';
	}

	/**
	 * Card title + body from Phase B answer. Title is the opening line; body omits that line.
	 *
	 * @return array{title:string,body:string}
	 */
	private static function split_answer_title_body( string $answer ): array {
		$answer = trim( $answer );
		if ( $answer === '' ) {
			return array(
				'title' => __( 'Here\'s what I found', 'flowbie-wp' ),
				'body'  => '',
			);
		}

		$parts = preg_split( '/(?<=[.!?])\s+/', $answer, 2 );
		$first = is_array( $parts ) && isset( $parts[0] ) ? trim( (string) $parts[0] ) : $answer;
		$rest  = is_array( $parts ) && isset( $parts[1] ) ? trim( (string) $parts[1] ) : '';

		$title = self::plain_text_from_markdown( $first );
		if ( $title === '' ) {
			$title = __( 'Here\'s what I found', 'flowbie-wp' );
		}

		return array(
			'title' => $title,
			'body'  => $rest,
		);
	}

	/**
	 * Strip markdown syntax for card titles (keep full visible text).
	 */
	private static function plain_text_from_markdown( string $text ): string {
		$text = preg_replace( '/\[([^\]]+)\]\([^)]+\)/', '$1', $text );
		$text = str_replace( array( '**', '__' ), '', $text );
		$text = preg_replace( '/\*([^*]+)\*/', '$1', $text );
		$text = preg_replace( '/_([^_]+)_/', '$1', $text );
		return trim( preg_replace( '/\s+/', ' ', $text ) );
	}

	/**
	 * Build a compact inventory summary for Phase A (IDs, titles, URLs, keywords, excerpt).
	 */
	private static function build_inventory_summary( array $index ): string {
		$lines = array();
		foreach ( $index as $item ) {
			$cats = ! empty( $item['categories'] ) ? ' [' . implode( ', ', $item['categories'] ) . ']' : '';
			$kw   = ! empty( $item['focus_keyword'] ) ? ' | kw:' . $item['focus_keyword'] : '';
			$preview = '';
			if ( ! empty( $item['excerpt'] ) ) {
				$preview = ' | excerpt:' . substr( (string) $item['excerpt'], 0, 80 );
				if ( strlen( (string) $item['excerpt'] ) > 80 ) {
					$preview .= '…';
				}
			}
			$lines[] = "ID:{$item['id']} | {$item['title']} | {$item['url']} | {$item['type']}{$cats}{$kw}{$preview}";
		}
		return implode( "\n", $lines );
	}

	/**
	 * Call OpenRouter with a specific model.
	 *
	 * @return string|WP_Error
	 */
	private static function call_openrouter( string $model, string $system_prompt, string $user_prompt, int $max_tokens = 2048, float $temperature = 0.5 ) {
		$key = Flowbie_Wp_OpenRouter::get_api_key();
		if ( $key === '' ) {
			return new WP_Error(
				'flowbie_openrouter_key',
				__( 'OpenRouter API key is not configured. Add it in Flowbie WP Settings > Editor AI.', 'flowbie-wp' )
			);
		}

		Flowbie_Wp_OpenRouter::maybe_extend_time_limit();

		$response = wp_remote_post(
			Flowbie_Wp_OpenRouter::API_URL,
			array(
				'timeout' => Flowbie_Wp_OpenRouter::get_timeout(),
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $key,
					'HTTP-Referer'  => Flowbie_Wp_OpenRouter::get_http_referer(),
					'X-Title'       => 'Flowbie Chat Widget',
				),
				'body'    => wp_json_encode(
					array(
						'model'       => $model,
						'messages'    => array(
							array( 'role' => 'system', 'content' => $system_prompt ),
							array( 'role' => 'user', 'content' => $user_prompt ),
						),
						'temperature' => $temperature,
						'max_tokens'  => $max_tokens,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( $code < 200 || $code >= 300 ) {
			$msg = '';
			if ( is_array( $data ) && isset( $data['error']['message'] ) ) {
				$msg = (string) $data['error']['message'];
			}
			if ( $msg === '' ) {
				$msg = sprintf( 'HTTP %d', $code );
			}
			return new WP_Error( 'flowbie_chat_ai', $msg );
		}

		$text = '';
		if ( is_array( $data ) && isset( $data['choices'][0]['message']['content'] ) ) {
			$text = trim( (string) $data['choices'][0]['message']['content'] );
		}

		if ( $text === '' ) {
			return new WP_Error( 'flowbie_chat_empty', __( 'AI returned empty content.', 'flowbie-wp' ) );
		}

		return $text;
	}

	/**
	 * Parse a JSON string from an LLM response, stripping markdown fences.
	 *
	 * @return array|null
	 */
	private static function parse_json_response( string $text ): ?array {
		$text = trim( $text );
		$text = preg_replace( '/^```(?:json)?\s*/i', '', $text );
		$text = preg_replace( '/\s*```$/', '', $text );
		$text = trim( $text );

		$decoded = json_decode( $text, true );
		return is_array( $decoded ) ? $decoded : null;
	}

	/**
	 * Guarantee at least MIN_RELATED_TOPICS chips after dedupe/backfill.
	 *
	 * @param array<string,mixed>              $card
	 * @param array<int,array<string,mixed>>     $items
	 * @param array<int,array<string,mixed>>     $site_index
	 * @param array<int,string>                $exclude_topics
	 * @return array<string,mixed>
	 */
	public static function ensure_minimum_related_topics( array $card, string $user_message, array $items, array $site_index, array $exclude_topics ): array {
		$topics = isset( $card['relatedTopics'] ) && is_array( $card['relatedTopics'] ) ? $card['relatedTopics'] : array();
		$topics = self::normalize_related_topics( $topics, $user_message, $exclude_topics );
		$seen   = self::related_topic_key_map( $topics );

		if ( count( $topics ) >= self::MIN_RELATED_TOPICS ) {
			$card['relatedTopics'] = array_slice( $topics, 0, self::MAX_RELATED_TOPICS );
			return $card;
		}

		if ( ! empty( $card['links'] ) && is_array( $card['links'] ) ) {
			foreach ( $card['links'] as $link ) {
				if ( count( $topics ) >= self::MIN_RELATED_TOPICS ) {
					break;
				}
				if ( ! is_array( $link ) ) {
					continue;
				}
				$candidate = self::related_topic_from_label( isset( $link['label'] ) ? (string) $link['label'] : '' );
				if ( $candidate === '' || self::should_skip_related_topic( $candidate, $user_message, $exclude_topics, $seen ) ) {
					continue;
				}
				$topics[] = $candidate;
				$seen[ strtolower( trim( $candidate ) ) ] = true;
			}
		}

		if ( count( $topics ) < self::MIN_RELATED_TOPICS ) {
			$link_pool = ! empty( $site_index ) ? $site_index : $items;
			foreach ( Flowbie_Wp_Chat_Links::pick_topic_links( $user_message, $items, 8, $link_pool, false ) as $link ) {
				if ( count( $topics ) >= self::MIN_RELATED_TOPICS ) {
					break;
				}
				$candidate = self::related_topic_from_label( isset( $link['label'] ) ? (string) $link['label'] : '' );
				if ( $candidate === '' || self::should_skip_related_topic( $candidate, $user_message, $exclude_topics, $seen ) ) {
					continue;
				}
				$topics[] = $candidate;
				$seen[ strtolower( trim( $candidate ) ) ] = true;
			}
		}

		if ( count( $topics ) < self::MIN_RELATED_TOPICS && ! empty( $site_index ) ) {
			$primary_urls = self::primary_item_url_map( $items );
			foreach ( self::sort_index_for_topic_backfill( $site_index ) as $item ) {
				if ( count( $topics ) >= self::MIN_RELATED_TOPICS ) {
					break;
				}
				if ( empty( $item['title'] ) ) {
					continue;
				}
				$url = isset( $item['url'] ) ? (string) $item['url'] : '';
				if ( $url !== '' && isset( $primary_urls[ strtolower( rtrim( $url, '/' ) ) ] ) ) {
					continue;
				}
				$candidate = self::related_topic_from_item( $item );
				if ( self::should_skip_related_topic( $candidate, $user_message, $exclude_topics, $seen ) ) {
					continue;
				}
				$topics[] = $candidate;
				$seen[ strtolower( trim( $candidate ) ) ] = true;
			}
		}

		if ( ! empty( $topics ) ) {
			$card['relatedTopics'] = array_slice( $topics, 0, self::MAX_RELATED_TOPICS );
		} else {
			unset( $card['relatedTopics'] );
		}

		return $card;
	}

	/**
	 * @param array<int,string> $topics
	 * @return array<int,string>
	 */
	private static function normalize_related_topics( array $topics, string $user_message, array $exclude_topics ): array {
		$out  = array();
		$seen = array();
		foreach ( $topics as $topic ) {
			if ( ! is_string( $topic ) ) {
				continue;
			}
			$topic = trim( $topic );
			if ( $topic === '' ) {
				continue;
			}
			$key = strtolower( $topic );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			if ( self::should_skip_related_topic( $topic, $user_message, $exclude_topics, $seen ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[]        = $topic;
		}
		return $out;
	}

	/**
	 * @param array<int,string> $topics
	 * @return array<string,bool>
	 */
	private static function related_topic_key_map( array $topics ): array {
		$map = array();
		foreach ( $topics as $topic ) {
			if ( ! is_string( $topic ) ) {
				continue;
			}
			$key = strtolower( trim( $topic ) );
			if ( $key !== '' ) {
				$map[ $key ] = true;
			}
		}
		return $map;
	}

	/**
	 * @param array<string,bool> $seen
	 */
	private static function should_skip_related_topic( string $topic, string $user_message, array $exclude_topics, array $seen ): bool {
		$key = strtolower( trim( $topic ) );
		if ( $key === '' || isset( $seen[ $key ] ) ) {
			return true;
		}
		if ( self::topic_matches_user_message( $topic, $user_message ) ) {
			return true;
		}
		foreach ( $exclude_topics as $exclude ) {
			if ( ! is_string( $exclude ) ) {
				continue;
			}
			if ( strtolower( trim( $exclude ) ) === $key ) {
				return true;
			}
		}
		return false;
	}

	private static function topic_matches_user_message( string $topic, string $message ): bool {
		$topic_norm   = strtolower( trim( $topic ) );
		$message_norm = strtolower( trim( $message ) );
		if ( $topic_norm === '' || $message_norm === '' ) {
			return false;
		}
		if ( $topic_norm === $message_norm ) {
			return true;
		}
		$prefix = 'tell me about ';
		if ( str_starts_with( $topic_norm, $prefix ) ) {
			$label = trim( substr( $topic_norm, strlen( $prefix ) ) );
			if ( $label !== '' && ( $message_norm === $label || str_contains( $message_norm, $label ) || str_contains( $label, $message_norm ) ) ) {
				return true;
			}
		}
		if ( str_starts_with( $message_norm, $prefix ) ) {
			$label = trim( substr( $message_norm, strlen( $prefix ) ) );
			if ( $label !== '' && ( $topic_norm === $label || str_contains( $topic_norm, $label ) || str_contains( $label, $topic_norm ) ) ) {
				return true;
			}
		}
		return false;
	}

	private static function related_topic_from_label( string $label ): string {
		$label = trim( wp_strip_all_tags( $label ) );
		if ( $label === '' ) {
			return '';
		}
		return 'Tell me about ' . $label;
	}

	/**
	 * @param array<string,mixed> $item
	 */
	private static function related_topic_from_item( array $item ): string {
		return self::related_topic_from_label( isset( $item['title'] ) ? (string) $item['title'] : '' );
	}

	/**
	 * @param array<int,array<string,mixed>> $items
	 * @return array<string,bool>
	 */
	private static function primary_item_url_map( array $items ): array {
		$map = array();
		foreach ( $items as $item ) {
			if ( empty( $item['url'] ) ) {
				continue;
			}
			$map[ strtolower( rtrim( (string) $item['url'], '/' ) ) ] = true;
		}
		return $map;
	}

	/**
	 * @param array<int,array<string,mixed>> $site_index
	 * @return array<int,array<string,mixed>>
	 */
	private static function sort_index_for_topic_backfill( array $site_index ): array {
		$pages = array();
		$rest  = array();
		foreach ( $site_index as $item ) {
			if ( isset( $item['type'] ) && (string) $item['type'] === 'page' ) {
				$pages[] = $item;
			} else {
				$rest[] = $item;
			}
		}
		return array_merge( $pages, $rest );
	}

	/**
	 * Produce an error card when the pipeline fails.
	 */
	private static function error_card( string $message ): array {
		return array(
			'type'       => 'not-found',
			'title'      => __( 'Something went wrong', 'flowbie-wp' ),
			'body'       => $message,
			'links'      => array(),
			'confidence' => 'low',
		);
	}

	/**
	 * Produce a fallback card when Phase C formatting fails but Phase B succeeded.
	 */
	private static function fallback_card( string $answer, array $items, string $user_message, array $classification, array $site_index = array(), array $history = array() ): array {
		$card = array(
			'type'       => 'answer',
			'title'      => __( 'Here\'s what I found', 'flowbie-wp' ),
			'body'       => $answer,
			'links'      => array(),
			'confidence' => 'medium',
		);

		$seen_urls   = Flowbie_Wp_Chat_History::collect_seen_urls( $history );
		$seen_topics = Flowbie_Wp_Chat_History::collect_seen_topics( $history );

		return Flowbie_Wp_Chat_Links::attach_to_card( $card, $user_message, $answer, $items, $classification, $site_index, $seen_urls, $seen_topics );
	}
}
