/**
 * Shared NDJSON stream handler for Flow Assist chat (frontend + admin demo).
 */
(function (global) {
  'use strict';

  var ACK_TO_CARD_MIN_MS = 800;

  function ensureThinkingShell(ctx) {
    if (!ctx) {
      return null;
    }
    if (ctx.thinkingShell) {
      return ctx.thinkingShell;
    }
    if (ctx.host && global.FlowbieThinkingCard) {
      ctx.thinkingShell = global.FlowbieThinkingCard.createThinkingCard(ctx.host, { stream: true });
      if (ctx.ackEl && ctx.messagesEl && ctx.thinkingShell.root) {
        if (ctx.ackEl.nextSibling) {
          ctx.messagesEl.insertBefore(ctx.thinkingShell.root, ctx.ackEl.nextSibling);
        } else {
          ctx.messagesEl.appendChild(ctx.thinkingShell.root);
        }
      }
    }
    return ctx.thinkingShell;
  }

  function appendAckBubble(messagesEl, text, scrollDown) {
    if (!messagesEl || !text) {
      return null;
    }
    var row = document.createElement('div');
    row.className = 'fcw-msg fcw-msg--assistant fcw-msg--ack';
    var bub = document.createElement('div');
    bub.className = 'fcw-ack-bubble';
    bub.textContent = text;
    row.appendChild(bub);
    messagesEl.appendChild(row);
    if (typeof scrollDown === 'function') {
      scrollDown();
    }
    return row;
  }

  function clearDoneTimer(ctx) {
    if (ctx && ctx.doneTimer) {
      clearTimeout(ctx.doneTimer);
      ctx.doneTimer = null;
    }
  }

  function presentDoneCard(evt, ctx) {
    clearDoneTimer(ctx);
    if (typeof ctx.onStreamEvent === 'function') {
      ctx.onStreamEvent(evt);
    }
    if (typeof ctx.presentCard !== 'function') {
      return;
    }

    var card = evt.card;
    var onDone = ctx.onDone;

    function finish() {
      var shell = ctx.thinkingShell || null;
      ctx.presentCard(card, { shell: shell, onDone: onDone });
    }

    if (ctx.ackShown && ctx.ackShownAt) {
      var wait = Math.max(0, ACK_TO_CARD_MIN_MS - (Date.now() - ctx.ackShownAt));
      ctx.doneTimer = setTimeout(finish, wait);
      return;
    }

    ensureThinkingShell(ctx);
    finish();
  }

  function handleEvent(evt, ctx) {
    if (!evt || !ctx) {
      return;
    }

    if (evt.status === 'ack' && evt.text && !ctx.ackShown) {
      ctx.ackShown = true;
      ctx.ackShownAt = Date.now();
      ctx.ackEl = appendAckBubble(ctx.messagesEl, evt.text, ctx.scrollDown);
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(function () {
          if (typeof ctx.scrollDown === 'function') {
            ctx.scrollDown();
          }
        });
      }
      return;
    }

    if (evt.status === 'done' && evt.card) {
      presentDoneCard(evt, ctx);
      return;
    }

    if (evt.label && !ctx.ackShown) {
      var thinkingShell = ensureThinkingShell(ctx);
      if (thinkingShell && global.FlowbieThinkingCard) {
        global.FlowbieThinkingCard.advanceStreamLabel(
          thinkingShell,
          ctx.host,
          evt.label
        );
      }
    } else if (evt.label && ctx.thinkingShell && global.FlowbieThinkingCard) {
      global.FlowbieThinkingCard.advanceStreamLabel(
        ctx.thinkingShell,
        ctx.host,
        evt.label
      );
    }

    if (typeof ctx.onStreamEvent === 'function') {
      ctx.onStreamEvent(evt);
    }
  }

  function createContext(base) {
    base = base || {};
    return {
      thinkingShell: base.thinkingShell || null,
      host: base.host || null,
      presentCard: base.presentCard || null,
      messagesEl: base.messagesEl || null,
      scrollDown: base.scrollDown || null,
      onDone: base.onDone || null,
      onStreamEvent: base.onStreamEvent || null,
      ackShown: false,
      ackShownAt: 0,
      ackEl: null,
      doneTimer: null
    };
  }

  global.FlowbieChatStream = {
    ACK_TO_CARD_MIN_MS: ACK_TO_CARD_MIN_MS,
    ensureThinkingShell: ensureThinkingShell,
    appendAckBubble: appendAckBubble,
    handleEvent: handleEvent,
    createContext: createContext,
    clearDoneTimer: clearDoneTimer
  };
})(typeof window !== 'undefined' ? window : this);
