/**
 * Lightweight markdown for Flow Assist answer cards (bold, links, lists).
 */
(function (global) {
  'use strict';

  function decodeDisplayText(text) {
    if (global.FlowbieDisplayText && typeof global.FlowbieDisplayText.decode === 'function') {
      return global.FlowbieDisplayText.decode(text);
    }
    return text == null ? '' : String(text);
  }

  function esc(text) {
    var d = document.createElement('div');
    d.textContent = decodeDisplayText(text);
    return d.innerHTML;
  }

  function telHref(raw) {
    var digits = String(raw).replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 15) {
      return '';
    }
    if (/^\s*\+/.test(raw)) {
      return 'tel:+' + digits;
    }
    return 'tel:' + digits;
  }

  function autoLinkContacts(html) {
    var saved = [];
    html = html.replace(/<a\b[^>]*>[\s\S]*?<\/a>/gi, function (match) {
      var id = saved.length;
      saved.push(match);
      return '\x00LINK' + id + '\x00';
    });

    html = html.replace(/\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b/g, function (_, email) {
      return '<a href="mailto:' + email + '">' + email + '</a>';
    });

    html = html.replace(/(?:\+?\d{1,3}[-.\s]?)?(?:\([0-9]{3}\)|[0-9]{3})[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b/g, function (match) {
      var href = telHref(match);
      if (!href) {
        return match;
      }
      return '<a href="' + href + '">' + match + '</a>';
    });

    html = html.replace(/\x00LINK(\d+)\x00/g, function (_, id) {
      return saved[Number(id)];
    });

    return html;
  }

  function repairOrphanLinkTails(text) {
    return String(text)
      .replace(/\[\[([^\]]+)\]\((https?:\/\/[^)]+)\)\]\((https?:\/\/[^)]+)\)/g, '[$1]($2)')
      .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)\]\((https?:\/\/[^)]+)\)/g, '[$1]($2)');
  }

  function protectMarkdownLinks(text) {
    var saved = [];
    var out = String(text).replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, function (match) {
      var id = saved.length;
      saved.push(match);
      return '\x00MDLINK' + id + '\x00';
    });
    return { text: out, saved: saved };
  }

  function restoreMarkdownLinks(text, saved) {
    return String(text).replace(/\x00MDLINK(\d+)\x00/g, function (_, id) {
      return saved[Number(id)];
    });
  }

  function inlineMarkdown(text) {
    var s = esc(text);
    s = repairOrphanLinkTails(s);
    var protectedLinks = protectMarkdownLinks(s);
    s = protectedLinks.text;
    s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    s = restoreMarkdownLinks(s, protectedLinks.saved);
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    s = s.replace(/\[([^\]]+)\]\((mailto:[^)]+)\)/gi, '<a href="$2">$1</a>');
    s = s.replace(/\[([^\]]+)\]\((tel:[^)]+)\)/gi, '<a href="$2">$1</a>');
    return autoLinkContacts(s);
  }

  function renderMarkdown(text) {
    if (text == null || text === '') {
      return '';
    }

    var lines = String(text).split('\n');
    var out = [];
    var inUl = false;
    var inOl = false;

    function closeLists() {
      if (inUl) {
        out.push('</ul>');
        inUl = false;
      }
      if (inOl) {
        out.push('</ol>');
        inOl = false;
      }
    }

    lines.forEach(function (line) {
      var trimmed = line.trim();
      var ulMatch = trimmed.match(/^[*\-]\s+(.+)$/);
      var olMatch = trimmed.match(/^\d+\.\s+(.+)$/);

      if (ulMatch) {
        if (inOl) {
          out.push('</ol>');
          inOl = false;
        }
        if (!inUl) {
          out.push('<ul class="fcw-md-list">');
          inUl = true;
        }
        out.push('<li>' + inlineMarkdown(ulMatch[1]) + '</li>');
        return;
      }

      if (olMatch) {
        if (inUl) {
          out.push('</ul>');
          inUl = false;
        }
        if (!inOl) {
          out.push('<ol class="fcw-md-list fcw-md-list--ordered">');
          inOl = true;
        }
        out.push('<li>' + inlineMarkdown(olMatch[1]) + '</li>');
        return;
      }

      closeLists();

      if (trimmed === '') {
        out.push('<br>');
        return;
      }

      out.push(inlineMarkdown(line) + '<br>');
    });

    closeLists();

    return out.join('').replace(/(<br>)+$/g, '');
  }

  global.FlowbieMarkdown = {
    render: renderMarkdown,
    inline: inlineMarkdown
  };
})(typeof window !== 'undefined' ? window : this);
