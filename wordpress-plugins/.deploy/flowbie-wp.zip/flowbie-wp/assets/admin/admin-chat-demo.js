(function () {
  'use strict';

  var cfg = window.flowbieChatDemo || {};
  var UI = cfg.ui || {};
  var root = document.getElementById('flowbie-chat-demo');
  if (!root) return;

  function uiOn(key) {
    return UI[key] !== false;
  }

  var msgs = document.getElementById('flowbie-chat-demo-messages');
  var empty = document.getElementById('flowbie-chat-demo-empty');
  var input = document.getElementById('flowbie-chat-demo-input');
  var btn = document.getElementById('flowbie-chat-demo-send');
  var form = root.querySelector('.fcw-demo-composer');
  var history = [];
  var ragConversationLog = [];
  var loading = false;
  function getChatSessionId() {
    var key = 'flowbie_chat_session_id';
    var id = sessionStorage.getItem(key);
    if (!id) {
      id = 'csess_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
      sessionStorage.setItem(key, id);
    }
    return id;
  }

  function historyStorageKey() {
    return 'flowbie_chat_history_' + getChatSessionId();
  }

  function loadHistory() {
    try {
      var raw = sessionStorage.getItem(historyStorageKey());
      if (raw) {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          history = parsed;
        }
      }
    } catch (_) {}
  }

  function saveHistory() {
    try {
      sessionStorage.setItem(historyStorageKey(), JSON.stringify(history.slice(-10)));
    } catch (_) {}
  }

  function pushHistoryTurn(role, content, card) {
    var turn = { role: role, content: content || '' };
    if (role === 'assistant' && card) {
      turn.card = {
        title: card.title,
        cta: card.cta,
        links: card.links,
        relatedTopics: card.relatedTopics
      };
    }
    history.push(turn);
    saveHistory();
  }

  loadHistory();

  if (!msgs || !input || !btn) return;

  var copyRagBtn = document.getElementById('flowbie-chat-demo-copy-rag');
  if (copyRagBtn) {
    copyRagBtn.addEventListener('click', function () {
      var payload = {
        session_id: getChatSessionId(),
        exported_at: new Date().toISOString(),
        turns: ragConversationLog
      };
      var text = JSON.stringify(payload, null, 2);
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        navigator.clipboard.writeText(text).then(function () {
          var prev = copyRagBtn.textContent;
          copyRagBtn.textContent = 'Copied';
          setTimeout(function () {
            copyRagBtn.textContent = prev;
          }, 2000);
        });
      }
    });
  }

  function hideEmpty() {
    if (empty) empty.hidden = true;
    msgs.hidden = false;
  }

  function clearChat() {
    if (loading) return;
    history = [];
    saveHistory();
    ragConversationLog = [];
    msgs.innerHTML = '';
    if (empty) empty.hidden = false;
    msgs.hidden = true;
    input.value = '';
    autoResize(input);
    if (window.FlowbieVoice && typeof window.FlowbieVoice.updateSendMicVisibility === 'function') {
      FlowbieVoice.updateSendMicVisibility(input, btn);
    }
  }

  var clearChatBtn = document.getElementById('flowbie-chat-demo-clear');
  if (clearChatBtn) {
    clearChatBtn.addEventListener('click', clearChat);
  }

  root.querySelectorAll('.fcw-demo-starter').forEach(function (chip) {
    chip.addEventListener('click', function () {
      var text = chip.getAttribute('data-prompt') || chip.textContent || '';
      if (text) deliverMessage(text.trim());
    });
  });

  btn.addEventListener('click', function () {
    if (input.value.trim()) send();
  });

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      send();
    });
  }

  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  });

  function bindVoiceWhenReady() {
    if (!window.FlowbieVoice || typeof window.FlowbieVoice.bindPtt !== 'function') {
      setTimeout(bindVoiceWhenReady, 50);
      return;
    }
    FlowbieVoice.bindPtt(btn, input, {
      isLoading: function () {
        return loading;
      },
      onTranscript: function (text) {
        deliverMessage(text);
      },
      onError: function (msg) {
        showVoiceToast(msg);
      }
    });
  }
  bindVoiceWhenReady();

  function showVoiceToast(msg) {
    hideEmpty();
    var row = document.createElement('div');
    row.className = 'fcw-msg fcw-msg--assistant';
    var t = document.createElement('div');
    t.className = 'flowbie-voice-toast';
    t.textContent = msg;
    row.appendChild(t);
    msgs.appendChild(row);
    setTimeout(function () {
      if (row.parentNode) row.parentNode.removeChild(row);
    }, 4500);
    scrollDown();
  }

  function deliverMessage(text) {
    if (!text || loading) return;
    hideEmpty();
    input.value = '';
    autoResize(input);
    if (window.FlowbieVoice && typeof window.FlowbieVoice.updateSendMicVisibility === 'function') {
      FlowbieVoice.updateSendMicVisibility(input, btn);
    }
    appendUser(text);
    pushHistoryTurn('user', text);
    ragConversationLog.push({
      timestamp: new Date().toISOString(),
      role: 'user',
      content: text
    });
    runStream(text);
  }

  function send() {
    var text = input.value.trim();
    if (!text || loading) return;
    deliverMessage(text);
  }

  function buildStepsList(steps) {
    var ul = document.createElement('ul');
    ul.className = 'fcw-thinking-steps';
    (steps || []).forEach(function (step, idx) {
      var st = step.status || 'pending';
      var li = document.createElement('li');
      li.className = 'fcw-thinking-step fcw-thinking-step--' + st;
      li.setAttribute('data-step-index', String(idx));
      var lbl = document.createElement('span');
      lbl.className = 'fcw-thinking-step-label';
      lbl.textContent = step.label || 'Step ' + (idx + 1);
      li.appendChild(lbl);
      ul.appendChild(li);
    });
    return ul;
  }

  function appendWorkflowCard(card) {
    hideEmpty();
    var row = document.createElement('div');
    row.className = 'fcw-msg fcw-msg--assistant';
    var c = document.createElement('div');
    c.className = 'fcw-card fcw-card--thinking-active';
    var tr = document.createElement('div');
    tr.className = 'fcw-card__title-row';
    var badge = null;
    if (uiOn('type_badge')) {
      badge = document.createElement('span');
      badge.className = 'fcw-card__type-badge';
      badge.textContent = 'working';
      tr.appendChild(badge);
    }
    var title = document.createElement('span');
    title.className = 'fcw-card__title';
    title.innerHTML = renderMd(card.title || 'Working on it\u2026');
    tr.appendChild(title);
    c.appendChild(tr);
    var body = document.createElement('div');
    body.className = 'fcw-card__body';
    if (card.body) {
      body.innerHTML = renderMd(card.body);
    } else {
      body.style.display = 'none';
    }
    c.appendChild(body);
    var stepsList = buildStepsList(card.steps || []);
    c.appendChild(stepsList);
    row.appendChild(c);
    msgs.appendChild(row);
    scrollDown();
    return { root: row, cardEl: c, badgeEl: badge, titleEl: title, bodyEl: body, stepsList: stepsList };
  }

  function setWorkflowStepStatus(shell, idx, status) {
    if (!shell || !shell.stepsList) return;
    var li = shell.stepsList.querySelector('[data-step-index="' + idx + '"]');
    if (!li) return;
    li.className = 'fcw-thinking-step fcw-thinking-step--' + status;
  }

  function setWorkflowCardActive(shell, active) {
    if (shell && shell.cardEl) {
      shell.cardEl.classList.toggle('fcw-card--thinking-active', !!active);
    }
  }

  function applyCardBadge(badgeEl, t) {
    badgeEl.textContent = t || 'answer';
  }

  function populateCardExtras(shell, card) {
    if (!shell || !shell.cardEl) return;
    var c = shell.cardEl;
    c.querySelectorAll('.fcw-card__confidence,.fcw-card__links,.fcw-card__cta-wrap,.fcw-card__topics').forEach(function (n) {
      if (n.parentNode) n.parentNode.removeChild(n);
    });
    if (uiOn('confidence')) {
      var confMap = { high: 'High confidence', medium: 'Based on site content', low: 'Limited information' };
      var conf = document.createElement('div');
      conf.className = 'fcw-card__confidence';
      conf.textContent = confMap[card.confidence] || confMap.medium;
      c.appendChild(conf);
    }
    if (uiOn('source_pills') && card.links && card.links.length) {
      var lw = document.createElement('div');
      lw.className = 'fcw-card__links';
      card.links.forEach(function (link) {
        var a = document.createElement('a');
        a.className = 'fcw-link-pill';
        a.href = link.url;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.textContent = link.label;
        lw.appendChild(a);
      });
      c.appendChild(lw);
    }
    if (uiOn('cta_buttons') && card.cta && card.cta.url) {
      var cw = document.createElement('div');
      cw.className = 'fcw-card__cta-wrap';
      var ca = document.createElement('a');
      ca.className = 'fcw-cta-btn';
      ca.href = card.cta.url;
      ca.target = '_blank';
      ca.rel = 'noopener noreferrer';
      ca.textContent = card.cta.label || 'Learn more';
      cw.appendChild(ca);
      c.appendChild(cw);
    }
    if (uiOn('suggestion_chips') && card.relatedTopics && card.relatedTopics.length) {
      var tw = document.createElement('div');
      tw.className = 'fcw-card__topics';
      card.relatedTopics.forEach(function (topic) {
        var chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'fcw-topic-chip';
        chip.textContent = topic;
        chip.addEventListener('click', function () {
          input.value = topic;
          send();
        });
        tw.appendChild(chip);
      });
      c.appendChild(tw);
    }
  }

  function thinkingHost() {
    return {
      appendWorkflowCard: appendWorkflowCard,
      setWorkflowStepStatus: setWorkflowStepStatus,
      setWorkflowCardActive: setWorkflowCardActive,
      applyCardBadge: applyCardBadge,
      renderMd: renderMd,
      populateCardExtras: populateCardExtras,
      scrollDown: scrollDown
    };
  }

  function presentCard(card, opts) {
    opts = opts || {};
    if (window.FlowbieDisplayText && typeof window.FlowbieDisplayText.decodeCard === 'function') {
      card = window.FlowbieDisplayText.decodeCard(card || {});
    }
    var shell = opts.shell;
    var host = thinkingHost();
    var finish = function () {
      pushHistoryTurn('assistant', card.body || card.title || '', card);
      if (typeof opts.onDone === 'function') opts.onDone();
    };
    if (shell && window.FlowbieThinkingCard) {
      FlowbieThinkingCard.finalizeToCard(shell, card, host);
    } else {
      appendCard(card);
    }
    finish();
    return Promise.resolve();
  }

  function runStream(text) {
    loading = true;
    btn.disabled = true;
    hideEmpty();
    var host = thinkingHost();
    var streamCtx = window.FlowbieChatStream
      ? FlowbieChatStream.createContext({
          host: host,
          messagesEl: msgs,
          scrollDown: scrollDown,
          presentCard: presentCard,
          onDone: function () {
            loading = false;
            btn.disabled = false;
            input.focus();
          },
          onStreamEvent: function (evt) {
            if (evt.status === 'done' && evt.card) {
              ragConversationLog.push({
                timestamp: new Date().toISOString(),
                role: 'assistant',
                card: evt.card,
                debug: evt.debug || null
              });
            }
          }
        })
      : null;
    var thinkingShell = null;
    var url = cfg.ajaxUrl + '?action=flowbie_chat_stream&_nonce=' + encodeURIComponent(cfg.streamNonce || '');
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: text,
        history: history.slice(-10),
        session_id: getChatSessionId(),
        source: 'demo',
        page_url: ''
      })
    })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var reader = res.body.getReader();
        var decoder = new TextDecoder();
        var buf = '';
        function pump() {
          return reader.read().then(function (result) {
            if (result.done) return;
            buf += decoder.decode(result.value, { stream: true });
            var lines = buf.split('\n');
            buf = lines.pop();
            lines.forEach(function (line) {
              line = line.trim();
              if (!line) return;
              var evt;
              try {
                evt = JSON.parse(line);
              } catch (_) {
                return;
              }
              if (streamCtx && window.FlowbieChatStream) {
                FlowbieChatStream.handleEvent(evt, streamCtx);
                thinkingShell = streamCtx.thinkingShell || thinkingShell;
              } else if (evt.status === 'done' && evt.card) {
                ragConversationLog.push({
                  timestamp: new Date().toISOString(),
                  role: 'assistant',
                  card: evt.card,
                  debug: evt.debug || null
                });
                presentCard(evt.card, {
                  shell: thinkingShell,
                  onDone: streamCtx ? streamCtx.onDone : undefined
                });
              } else if (evt.label && thinkingShell && window.FlowbieThinkingCard) {
                FlowbieThinkingCard.advanceStreamLabel(thinkingShell, host, evt.label);
              }
            });
            return pump();
          });
        }
        return pump();
      })
      .catch(function () {
        loading = false;
        btn.disabled = false;
        if (window.FlowbieVoice) FlowbieVoice.updateSendMicVisibility(input, btn);
        if (streamCtx && window.FlowbieChatStream) {
          thinkingShell = FlowbieChatStream.ensureThinkingShell(streamCtx);
        }
        presentCard(
          {
            type: 'not-found',
            title: 'Connection error',
            body: 'Could not reach the server.',
            confidence: 'low'
          },
          {
            shell: thinkingShell,
            onDone: function () {
              input.focus();
            }
          }
        );
      });
  }

  function appendUser(text) {
    var row = document.createElement('div');
    row.className = 'fcw-msg fcw-msg--user';
    var bubble = document.createElement('div');
    bubble.className = 'fcw-user-bubble';
    bubble.textContent = text;
    row.appendChild(bubble);
    msgs.appendChild(row);
    scrollDown();
  }

  function appendCard(card) {
    hideEmpty();
    var row = document.createElement('div');
    row.className = 'fcw-msg fcw-msg--assistant';
    var c = document.createElement('div');
    c.className = 'fcw-card';
    var tr = document.createElement('div');
    tr.className = 'fcw-card__title-row';
    if (uiOn('type_badge')) {
      var badge = document.createElement('span');
      badge.className = 'fcw-card__type-badge';
      badge.textContent = card.type || 'answer';
      tr.appendChild(badge);
    }
    var title = document.createElement('span');
    title.className = 'fcw-card__title';
    title.innerHTML = renderMd(card.title || '');
    tr.appendChild(title);
    c.appendChild(tr);
    if (card.body) {
      var body = document.createElement('div');
      body.className = 'fcw-card__body';
      body.innerHTML = renderMd(card.body);
      c.appendChild(body);
    }
    populateCardExtras({ cardEl: c }, card);
    row.appendChild(c);
    msgs.appendChild(row);
    scrollDown();
  }

  function scrollDown() {
    requestAnimationFrame(function () {
      msgs.scrollTop = msgs.scrollHeight;
    });
  }

  function autoResize(ta) {
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
  }

  input.addEventListener('input', function () {
    autoResize(input);
  });

  function renderMd(text) {
    if (window.FlowbieMarkdown && typeof window.FlowbieMarkdown.render === 'function') {
      return FlowbieMarkdown.render(text);
    }
    var d = document.createElement('div');
    d.textContent = text;
    var s = d.innerHTML;
    s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    s = s.replace(/\n/g, '<br>');
    return s;
  }
})();
