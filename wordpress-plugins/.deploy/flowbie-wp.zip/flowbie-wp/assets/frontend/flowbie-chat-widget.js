/**
 * Flowbie Chat Widget – Dark Glassmorphism Edition
 *
 * Reads config from the global `flowbieChatConfig` object injected by
 * wp_localize_script (restUrl, nonce, siteName, welcomeMessage, color, assistantName).
 */
(function () {
  'use strict';

  var cfg = window.flowbieChatConfig || {};
  if (!cfg.restUrl) return;

  var root = document.getElementById('flowbie-chat-widget-root');
  if (!root) return;

  var ASSISTANT = cfg.assistantName || 'Flow Assist';
  var UI = cfg.ui || {};
  var SIDEBAR_SIDE = cfg.sidebarSide === 'left' ? 'left' : 'right';
  var SIDEBAR_TRANSITION = cfg.sidebarTransition || 'slide';
  var SIDEBAR_LAYOUT = Array.isArray(cfg.sidebarLayout) ? cfg.sidebarLayout : ['chat'];
  var SHOW_SIDEBAR_HEADING = SIDEBAR_LAYOUT.indexOf('heading') !== -1 && cfg.sidebarHeading;
  var SHOW_CHAT_BODY = SIDEBAR_LAYOUT.indexOf('chat') !== -1 || SIDEBAR_LAYOUT.length === 0;
  var sidebarShell = null;
  var isOpen = false;
  var history = [];
  var isLoading = false;

  var SVG_CLOSE = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
  var SVG_TRASH = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>';
  var SVG_SEND = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
  var SVG_ICON_PAGE = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 1h5.5L13 4.5V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z"/><polyline points="9 1 9 5 13 5"/></svg>';
  var SVG_ICON_POST = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="12" height="12" rx="1"/><line x1="5" y1="5" x2="11" y2="5"/><line x1="5" y1="8" x2="11" y2="8"/><line x1="5" y1="11" x2="8" y2="11"/></svg>';
  var SVG_ICON_EXT = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 9v4a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h4"/><polyline points="8 2 14 2 14 8"/><line x1="14" y1="2" x2="7" y2="9"/></svg>';
  var SVG_CHAT_LAUNCHER = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
  var SVG_STAR = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.4 7.4H22l-6 4.6 2.3 7-6.3-4.6L5.7 21l2.3-7-6-4.6h7.6z"/></svg>';
  var STARTERS = Array.isArray(cfg.conversationStarters) ? cfg.conversationStarters : [];
  var GREETING_LINE = cfg.greetingLine || 'Hello';
  var GREETING_SUB = cfg.greetingSubline || 'How can I help you today?';
  var COMPOSER_PLACEHOLDER = cfg.composerPlaceholder || ('Ask about ' + (cfg.siteName || 'this site') + '\u2026');

  function uiOn(key) {
    return UI[key] !== false;
  }

  function getChatSessionId() {
    var key = 'flowbie_chat_session_id';
    var id = sessionStorage.getItem(key);
    if (!id) {
      id = 'csess_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
      sessionStorage.setItem(key, id);
    }
    return id;
  }

  function historyStorageKey() {
    return 'flowbie_chat_history_' + getChatSessionId();
  }

  function loadHistory() {
    try {
      var raw = sessionStorage.getItem(historyStorageKey());
      if (raw) {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          history = parsed;
        }
      }
    } catch (_) {}
  }

  function saveHistory() {
    try {
      sessionStorage.setItem(historyStorageKey(), JSON.stringify(history.slice(-10)));
    } catch (_) {}
  }

  function pushHistoryTurn(role, content, card) {
    var turn = { role: role, content: content || '' };
    if (role === 'assistant' && card) {
      turn.card = {
        title: card.title,
        cta: card.cta,
        links: card.links,
        relatedTopics: card.relatedTopics
      };
    }
    history.push(turn);
    saveHistory();
  }

  loadHistory();

  function recordChatAccept(messageId, url, label, type) {
    if (!messageId || !cfg.acceptUrl) return;
    fetch(cfg.acceptUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': cfg.nonce
      },
      body: JSON.stringify({
        messageId: messageId,
        url: url,
        label: label,
        type: type
      }),
      keepalive: true
    }).catch(function () {});
  }

  function bindAcceptClick(anchor, card, type, label) {
    if (!card || !card.message_uid) return;
    anchor.addEventListener('click', function () {
      recordChatAccept(
        card.message_uid,
        anchor.href,
        label || anchor.textContent || '',
        type
      );
    });
  }

  // ── DOM scaffold ──────────────────────────────────────────────

  root.innerHTML = '';
  root.className = 'flowbie-chat-widget flowbie-chat--sidebar fai-sidebar-root fai-sidebar-root--' + SIDEBAR_SIDE +
    ' fai-sidebar-root--transition-' + SIDEBAR_TRANSITION;
  if (cfg.cssVars) {
    root.setAttribute('style', cfg.cssVars);
  }
  var hideMap = {
    header: 'fcw-hide-header',
    assistant_name: 'fcw-hide-assistant-name',
    close_button: 'fcw-hide-close-button',
    thinking_card: 'fcw-hide-thinking-card',
    source_pills: 'fcw-hide-source-pills',
    cta_buttons: 'fcw-hide-cta-buttons',
    suggestion_chips: 'fcw-hide-suggestion-chips',
    confidence: 'fcw-hide-confidence',
    type_badge: 'fcw-hide-type-badge',
    send_button: 'fcw-hide-send-button'
  };
  Object.keys(hideMap).forEach(function (k) {
    if (!uiOn(k)) root.classList.add(hideMap[k]);
  });

  var backdrop = el('div', { className: 'fai-sidebar-backdrop', 'aria-hidden': 'true' });

  var panel = el('div', {
    className: 'fai-sidebar-panel fcw-panel fcw-panel--sidebar'
  });

  var closeBtn = el('button', {
    className: 'fai-sidebar-close fcw-header__close',
    'aria-label': 'Close chat',
    innerHTML: SVG_CLOSE
  });
  var clearBtn = el('button', {
    type: 'button',
    className: 'fai-sidebar-clear fcw-header__clear',
    'aria-label': 'Clear chat',
    innerHTML: SVG_TRASH
  });
  var toolbarActions = el('div', { className: 'fai-sidebar-toolbar-actions' });
  toolbarActions.appendChild(clearBtn);
  if (uiOn('close_button')) {
    toolbarActions.appendChild(closeBtn);
  }
  var toolbar = el('div', { className: 'fai-sidebar-panel__toolbar' });
  toolbar.appendChild(toolbarActions);

  var emptyEl = null;
  var messages = el('div', { className: 'fcw-messages' });
  if (uiOn('welcome_message')) {
    emptyEl = el('div', { className: 'fcw-empty' });
    var greetingBlock = el('div');
    var greeting = el('p', { className: 'fcw-greeting' });
    greeting.textContent = GREETING_LINE;
    var sub = el('p', { className: 'fcw-sub' });
    sub.textContent = GREETING_SUB;
    greetingBlock.appendChild(greeting);
    greetingBlock.appendChild(sub);
    emptyEl.appendChild(greetingBlock);
    if (STARTERS.length && uiOn('suggestion_chips')) {
      var startersWrap = el('div', { className: 'fcw-starters' });
      STARTERS.forEach(function (prompt) {
        var chip = el('button', {
          type: 'button',
          className: 'fcw-starter',
          'data-prompt': prompt
        });
        chip.textContent = prompt;
        chip.addEventListener('click', function () {
          var text = chip.getAttribute('data-prompt') || chip.textContent || '';
          if (text.trim()) deliverMessage(text.trim());
        });
        startersWrap.appendChild(chip);
      });
      emptyEl.appendChild(startersWrap);
    }
    messages.setAttribute('hidden', '');
  }

  var inputRow = el('form', { className: 'fcw-input-row fcw-composer' });
  var composerShell = el('div', { className: 'fcw-composer-shell' });
  var composerActions = el('div', { className: 'fcw-composer-actions' });
  var textarea = el('textarea', {
    className: 'fcw-textarea',
    placeholder: COMPOSER_PLACEHOLDER,
    rows: 1
  });
  var sendBtn = el('button', {
    className: 'fcw-send',
    type: 'button',
    'aria-label': 'Hold to speak',
    innerHTML: '<span class="fcw-send__icon fcw-send__icon--send" aria-hidden="true">' + SVG_STAR + '</span>'
  });

  composerShell.appendChild(textarea);
  composerActions.appendChild(sendBtn);
  composerShell.appendChild(composerActions);
  inputRow.appendChild(composerShell);

  var panelBody = el('div', { className: 'fai-sidebar-panel__body' });
  if (SHOW_SIDEBAR_HEADING) {
    var headingEl = el('h2', { className: 'fai-sidebar-heading fcw-sidebar-heading' });
    headingEl.textContent = cfg.sidebarHeading;
    panelBody.appendChild(headingEl);
  }
  var chatMain = el('div', { className: 'fcw-sidebar-main' });
  if (SHOW_CHAT_BODY) {
    if (emptyEl) chatMain.appendChild(emptyEl);
    chatMain.appendChild(messages);
    chatMain.appendChild(inputRow);
  }
  panelBody.appendChild(chatMain);
  panel.appendChild(toolbar);
  panel.appendChild(panelBody);
  panel.setAttribute('role', 'complementary');
  panel.setAttribute('aria-label', ASSISTANT);
  panel.setAttribute('hidden', '');
  root.appendChild(backdrop);
  root.appendChild(panel);

  function hideEmpty() {
    if (emptyEl) emptyEl.hidden = true;
    messages.hidden = false;
  }

  function clearChat() {
    if (isLoading) return;
    history = [];
    saveHistory();
    messages.innerHTML = '';
    if (emptyEl) {
      emptyEl.hidden = false;
      messages.hidden = true;
    }
    textarea.value = '';
    autoResize(textarea);
    if (window.FlowbieVoice && typeof window.FlowbieVoice.updateSendMicVisibility === 'function') {
      FlowbieVoice.updateSendMicVisibility(textarea, sendBtn);
    }
  }

  clearBtn.addEventListener('click', clearChat);

  // ── Events ────────────────────────────────────────────────────

  inputRow.addEventListener('submit', onSubmit);

  function fcwBuildStepsList(steps) {
    var ul = el('ul', { className: 'fcw-thinking-steps' });
    (steps || []).forEach(function (step, idx) {
      var st = step.status || 'pending';
      var li = el('li', { className: 'fcw-thinking-step fcw-thinking-step--' + st });
      li.setAttribute('data-step-index', String(idx));
      var lbl = el('span', { className: 'fcw-thinking-step-label' });
      lbl.textContent = step.label || 'Step ' + (idx + 1);
      li.appendChild(lbl);
      ul.appendChild(li);
    });
    return ul;
  }

  function fcwAppendWorkflowCard(card) {
    var row = el('div', { className: 'fcw-msg fcw-msg--assistant' });
    var cardEl = el('div', { className: 'fcw-card fcw-card--thinking-active' });
    var titleRow = el('div', { className: 'fcw-card__title-row' });
    var badge = null;
    if (uiOn('type_badge')) {
      badge = el('span', { className: 'fcw-card__type-badge' });
      badge.textContent = 'working';
      titleRow.appendChild(badge);
    }
    var title = el('span', { className: 'fcw-card__title' });
    title.innerHTML = renderMarkdown(card.title || 'Working on it\u2026');
    titleRow.appendChild(title);
    cardEl.appendChild(titleRow);
    var bodyEl = el('div', { className: 'fcw-card__body' });
    if (card.body) {
      bodyEl.innerHTML = renderMarkdown(card.body);
    } else {
      bodyEl.style.display = 'none';
    }
    cardEl.appendChild(bodyEl);
    var stepsList = fcwBuildStepsList(card.steps || []);
    cardEl.appendChild(stepsList);
    row.appendChild(cardEl);
    messages.appendChild(row);
    scrollDown();
    return { root: row, cardEl: cardEl, badgeEl: badge, titleEl: title, bodyEl: bodyEl, stepsList: stepsList };
  }

  function fcwSetWorkflowStepStatus(shell, idx, status) {
    if (!shell || !shell.stepsList) return;
    var li = shell.stepsList.querySelector('[data-step-index="' + idx + '"]');
    if (!li) return;
    li.className = 'fcw-thinking-step fcw-thinking-step--' + status;
  }

  function fcwSetWorkflowCardActive(shell, active) {
    if (shell && shell.cardEl) {
      shell.cardEl.classList.toggle('fcw-card--thinking-active', !!active);
    }
  }

  function fcwApplyCardBadge(badgeEl, t) {
    badgeEl.textContent = t || 'answer';
  }

  function fcwPopulateCardExtras(shell, card) {
    if (!shell || !shell.cardEl) return;
    var cardEl = shell.cardEl;
    var old = cardEl.querySelectorAll('.fcw-card__confidence, .fcw-card__links, .fcw-card__cta-wrap, .fcw-card__topics');
    old.forEach(function (n) { if (n.parentNode) n.parentNode.removeChild(n); });
    if (uiOn('confidence')) {
      var confMap = { high: 'High confidence', medium: 'Based on site content', low: 'Limited information' };
      var conf = el('div', { className: 'fcw-card__confidence' });
      conf.textContent = confMap[card.confidence] || confMap.medium;
      cardEl.appendChild(conf);
    }
    if (uiOn('source_pills') && card.links && card.links.length) {
      var linksWrap = el('div', { className: 'fcw-card__links' });
      card.links.forEach(function (link) {
        var a = el('a', { className: 'fcw-link-pill', href: link.url, target: '_blank', rel: 'noopener noreferrer' });
        a.textContent = link.label;
        bindAcceptClick(a, card, 'source', link.label);
        linksWrap.appendChild(a);
      });
      cardEl.appendChild(linksWrap);
    }
    if (uiOn('cta_buttons') && card.cta && card.cta.url) {
      var ctaWrap = el('div', { className: 'fcw-card__cta-wrap' });
      var cta = el('a', { className: 'fcw-cta-btn', href: card.cta.url, target: '_blank', rel: 'noopener noreferrer' });
      cta.textContent = (card.cta.label && String(card.cta.label).trim()) ? String(card.cta.label).trim() : 'Learn more';
      bindAcceptClick(cta, card, 'cta', cta.textContent);
      ctaWrap.appendChild(cta);
      cardEl.appendChild(ctaWrap);
    }
    if (uiOn('suggestion_chips') && card.relatedTopics && card.relatedTopics.length) {
      var topics = el('div', { className: 'fcw-card__topics' });
      card.relatedTopics.forEach(function (topic) {
        var chip = el('button', { className: 'fcw-topic-chip', type: 'button' });
        chip.textContent = topic;
        chip.addEventListener('click', function () {
          textarea.value = topic;
          inputRow.dispatchEvent(new Event('submit'));
        });
        topics.appendChild(chip);
      });
      cardEl.appendChild(topics);
    }
  }

  function fcwThinkingHost() {
    return {
      appendWorkflowCard: fcwAppendWorkflowCard,
      setWorkflowStepStatus: fcwSetWorkflowStepStatus,
      setWorkflowCardActive: fcwSetWorkflowCardActive,
      applyCardBadge: fcwApplyCardBadge,
      renderMd: renderMarkdown,
      populateCardExtras: fcwPopulateCardExtras,
      scrollDown: scrollDown
    };
  }

  function presentCard(card, opts) {
    opts = opts || {};
    if (window.FlowbieDisplayText && typeof window.FlowbieDisplayText.decodeCard === 'function') {
      card = window.FlowbieDisplayText.decodeCard(card || {});
    }
    var shell = opts.shell;
    var host = fcwThinkingHost();
    var done = function () {
      pushHistoryTurn('assistant', card.body || card.title || '', card);
      if (typeof opts.onDone === 'function') {
        opts.onDone();
      }
    };
    if (shell && window.FlowbieThinkingCard) {
      FlowbieThinkingCard.finalizeToCard(shell, card, host);
    } else {
      appendCard(card);
    }
    done();
    return Promise.resolve();
  }

  sendBtn.addEventListener('click', function () {
    if (textarea.value.trim()) {
      inputRow.dispatchEvent(new Event('submit'));
    }
  });
  textarea.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      inputRow.dispatchEvent(new Event('submit'));
    }
  });

  if (cfg.voiceEnabled && window.FlowbieVoice && uiOn('mic_button')) {
    FlowbieVoice.init({
      transcribeUrl: cfg.transcribeUrl,
      voiceNonce: cfg.streamNonce,
      micReplacesSend: cfg.micReplacesSend !== false
    });
    if (cfg.voicePtt !== false) {
      FlowbieVoice.bindPtt(sendBtn, textarea, {
        isLoading: function () { return isLoading; },
        onTranscript: function (text) { deliverMessage(text); },
        onError: function (msg) {
          if (uiOn('voice_toast')) showVoiceToast(msg);
        }
      });
    }
  }

  function getUnifiedShell() {
    if (window.FlowbieAiSidebarUnify && window.FlowbieAiSidebarUnify.isMerged()) {
      return window.FlowbieAiSidebarUnify.getShell();
    }
    return null;
  }

  function onSidebarOpen() {
    isOpen = true;
    textarea.focus();
  }

  function onSidebarClose() {
    isOpen = false;
  }

  function removeStandaloneLauncher() {
    var launcher = root.querySelector('.fcw-launcher');
    if (launcher && launcher.parentNode) {
      launcher.parentNode.removeChild(launcher);
    }
    root.classList.remove('flowbie-chat--standalone-launcher');
  }

  function ensureStandaloneLauncher() {
    var existing = root.querySelector('.fai-sidebar-launcher, .fbs__icon-launcher');
    if (existing) {
      return existing;
    }
    root.classList.add('flowbie-chat--standalone-launcher');
    var launcher = el('button', {
      type: 'button',
      className: 'fai-sidebar-launcher fcw-launcher',
      'aria-label': cfg.launcherLabel || ('Open ' + ASSISTANT),
      'aria-expanded': 'false',
      innerHTML: SVG_CHAT_LAUNCHER
    });
    root.appendChild(launcher);
    return launcher;
  }

  function bindShellCallbacks(shell) {
    if (!shell || shell._fcwBound) {
      return;
    }
    shell._fcwBound = true;
    var prevOnOpen = shell.opts.onOpen;
    var prevOnClose = shell.opts.onClose;
    shell.opts.onOpen = function () {
      if (typeof prevOnOpen === 'function') prevOnOpen();
      onSidebarOpen();
    };
    shell.opts.onClose = function () {
      if (typeof prevOnClose === 'function') prevOnClose();
      onSidebarClose();
    };
  }

  function initStandaloneShell() {
    if (!window.FlowbieAiSidebarShell || sidebarShell || getUnifiedShell()) {
      return;
    }
    ensureStandaloneLauncher();
    sidebarShell = window.FlowbieAiSidebarShell.init(root, {
      backdrop: backdrop,
      panel: panel,
      onOpen: onSidebarOpen,
      onClose: onSidebarClose
    });
    sidebarShell._fcwBound = true;
  }

  function bindUnifiedShell() {
    if (window.FlowbieAiSidebarUnify) {
      window.FlowbieAiSidebarUnify.tryMerge();
    }
    var shell = getUnifiedShell();
    if (shell) {
      removeStandaloneLauncher();
      bindShellCallbacks(shell);
      sidebarShell = shell;
      return;
    }
    if (document.readyState === 'loading') {
      return;
    }
    initStandaloneShell();
  }

  bindUnifiedShell();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindUnifiedShell);
  }
  document.addEventListener('flowbie-ai-sidebar-merged', bindUnifiedShell);

  function onSubmit(e) {
    e.preventDefault();
    var text = textarea.value.trim();
    if (!text || isLoading) return;
    deliverMessage(text);
  }

  function deliverMessage(text) {
    if (!text || isLoading) return;
    hideEmpty();
    textarea.value = '';
    autoResize(textarea);
    if (window.FlowbieVoice && typeof window.FlowbieVoice.updateSendMicVisibility === 'function') {
      FlowbieVoice.updateSendMicVisibility(textarea, sendBtn);
    }
    appendUserBubble(text);
    pushHistoryTurn('user', text);
    sendMessage(text);
  }

  function showVoiceToast(msg) {
    var row = el('div', { className: 'fcw-msg fcw-msg--assistant' });
    var t = el('div', { className: 'flowbie-voice-toast' });
    t.textContent = msg;
    row.appendChild(t);
    messages.appendChild(row);
    scrollDown();
    setTimeout(function () {
      if (row.parentNode) row.parentNode.removeChild(row);
    }, 4500);
  }

  // ── API (streaming via admin-ajax) ────────────────────────────

  function sendMessage(text) {
    isLoading = true;
    sendBtn.disabled = true;
    if (window.FlowbieVoice) {
      FlowbieVoice.updateSendMicVisibility(textarea, sendBtn);
    }
    var host = fcwThinkingHost();
    var streamCtx = window.FlowbieChatStream
      ? FlowbieChatStream.createContext({
          host: host,
          messagesEl: messages,
          scrollDown: scrollDown,
          presentCard: presentCard,
          onDone: function () {
            isLoading = false;
            sendBtn.disabled = false;
            if (window.FlowbieVoice) {
              FlowbieVoice.updateSendMicVisibility(textarea, sendBtn);
            }
          }
        })
      : null;
    var thinkingShell = null;

    var url = (cfg.ajaxUrl || cfg.restUrl) +
      '?action=flowbie_chat_stream&_nonce=' + encodeURIComponent(cfg.streamNonce || '');

    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: text,
        history: history.slice(-10),
        session_id: getChatSessionId(),
        source: 'frontend',
        page_url: window.location.href || ''
      })
    }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      var reader = res.body.getReader();
      var decoder = new TextDecoder();
      var buf = '';

      function pump() {
        return reader.read().then(function (result) {
          if (result.done) return;
          buf += decoder.decode(result.value, { stream: true });
          var lines = buf.split('\n');
          buf = lines.pop();
          lines.forEach(function (line) {
            line = line.trim();
            if (!line) return;
            var evt;
            try { evt = JSON.parse(line); } catch (_) { return; }
            if (streamCtx && window.FlowbieChatStream) {
              FlowbieChatStream.handleEvent(evt, streamCtx);
              thinkingShell = streamCtx.thinkingShell || thinkingShell;
            } else if (evt.status === 'done' && evt.card) {
              presentCard(evt.card, {
                shell: thinkingShell,
                onDone: streamCtx ? streamCtx.onDone : undefined
              });
            } else if (evt.label && thinkingShell && window.FlowbieThinkingCard) {
              FlowbieThinkingCard.advanceStreamLabel(thinkingShell, host, evt.label);
            }
          });
          return pump();
        });
      }
      return pump();
    }).catch(function () {
      isLoading = false;
      sendBtn.disabled = false;
      if (window.FlowbieVoice) {
        FlowbieVoice.updateSendMicVisibility(textarea, sendBtn);
      }
      if (streamCtx && window.FlowbieChatStream) {
        thinkingShell = FlowbieChatStream.ensureThinkingShell(streamCtx);
      }
      presentCard({
        type: 'not-found',
        title: 'Connection error',
        body: 'Could not reach the server. Please check your internet connection.',
        confidence: 'low'
      }, { shell: thinkingShell });
    });
  }

  // ── Rendering ─────────────────────────────────────────────────

  function appendUserBubble(text) {
    var row = el('div', { className: 'fcw-msg fcw-msg--user' });
    var bub = el('div', { className: 'fcw-user-bubble' });
    bub.textContent = text;
    row.appendChild(bub);
    messages.appendChild(row);
    scrollDown();
  }

  function appendCard(card) {
    var row = el('div', { className: 'fcw-msg fcw-msg--assistant' });
    var cardEl = el('div', { className: 'fcw-card' });

    var titleRow = el('div', { className: 'fcw-card__title-row' });

    if (uiOn('type_badge')) {
      var badge = el('span', {
        className: 'fcw-card__type-badge'
      });
      badge.textContent = card.type || 'answer';
      titleRow.appendChild(badge);
    }

    var title = el('span', { className: 'fcw-card__title' });
    title.innerHTML = renderMarkdown(card.title || '');
    titleRow.appendChild(title);
    cardEl.appendChild(titleRow);

    if (card.body) {
      var body = el('div', { className: 'fcw-card__body' });
      body.innerHTML = renderMarkdown(card.body);
      cardEl.appendChild(body);
    }

    var confMap = {
      high: 'High confidence',
      medium: 'Based on site content',
      low: 'Limited information'
    };
    if (uiOn('confidence')) {
      var conf = el('div', { className: 'fcw-card__confidence' });
      conf.textContent = confMap[card.confidence] || confMap.medium;
      cardEl.appendChild(conf);
    }

    if (uiOn('source_pills') && card.links && card.links.length) {
      var linksWrap = el('div', { className: 'fcw-card__links' });
      card.links.forEach(function (link) {
        var a = el('a', {
          className: 'fcw-link-pill',
          href: link.url,
          target: '_blank',
          rel: 'noopener noreferrer'
        });
        var icon = linkIcon(link.icon);
        if (icon) {
          var iconSpan = el('span', { className: 'fcw-link-pill__icon', innerHTML: icon });
          a.appendChild(iconSpan);
        }
        var lbl = el('span', {});
        lbl.textContent = link.label;
        a.appendChild(lbl);
        bindAcceptClick(a, card, 'source', link.label);
        linksWrap.appendChild(a);
      });
      cardEl.appendChild(linksWrap);
    }

    if (uiOn('cta_buttons') && card.cta && card.cta.url) {
      var ctaWrap = el('div', { className: 'fcw-card__cta-wrap' });
      var cta = el('a', {
        className: 'fcw-cta-btn',
        href: card.cta.url,
        target: '_blank',
        rel: 'noopener noreferrer'
      });
      cta.textContent = (card.cta.label && String(card.cta.label).trim()) ? String(card.cta.label).trim() : 'Learn more';
      bindAcceptClick(cta, card, 'cta', cta.textContent);
      ctaWrap.appendChild(cta);
      cardEl.appendChild(ctaWrap);
    }

    if (uiOn('suggestion_chips') && card.relatedTopics && card.relatedTopics.length) {
      var topics = el('div', { className: 'fcw-card__topics' });
      card.relatedTopics.forEach(function (topic) {
        var chip = el('button', { className: 'fcw-topic-chip', type: 'button' });
        chip.textContent = topic;
        chip.addEventListener('click', function () {
          textarea.value = topic;
          inputRow.dispatchEvent(new Event('submit'));
        });
        topics.appendChild(chip);
      });
      cardEl.appendChild(topics);
    }

    row.appendChild(cardEl);
    messages.appendChild(row);
    scrollDown();
  }

  function appendStatus(label) {
    var row = el('div', { className: 'fcw-msg fcw-msg--assistant' });
    var s = el('div', { className: 'fcw-status' });
    s.textContent = label;
    row.appendChild(s);
    messages.appendChild(row);
    scrollDown();
    return row;
  }

  function updateStatus(row, label) {
    var s = row && row.querySelector('.fcw-status');
    if (s) s.textContent = label;
    scrollDown();
  }

  function removeStatus(row) {
    if (row && row.parentNode) {
      row.parentNode.removeChild(row);
    }
  }

  function scrollDown() {
    requestAnimationFrame(function () {
      messages.scrollTop = messages.scrollHeight;
    });
  }

  // ── Helpers ───────────────────────────────────────────────────

  function el(tag, attrs) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === 'className') node.className = attrs[k];
        else if (k === 'innerHTML') node.innerHTML = attrs[k];
        else node.setAttribute(k, attrs[k]);
      });
    }
    return node;
  }

  function esc(s) {
    var d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  function renderMarkdown(text) {
    if (window.FlowbieMarkdown && typeof window.FlowbieMarkdown.render === 'function') {
      return FlowbieMarkdown.render(text);
    }
    var s = esc(text);
    s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    s = s.replace(/\n/g, '<br>');
    return s;
  }

  function linkIcon(type) {
    if (type === 'post') return SVG_ICON_POST;
    if (type === 'page') return SVG_ICON_PAGE;
    if (type === 'external') return SVG_ICON_EXT;
    return SVG_ICON_PAGE;
  }

  function autoResize(ta) {
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 120) + 'px';
  }
  textarea.addEventListener('input', function () { autoResize(textarea); });
})();
