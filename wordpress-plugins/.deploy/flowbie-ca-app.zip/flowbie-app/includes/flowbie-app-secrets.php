<?php
/**
 * Production secrets for flowbie.ca (gitignored). Domain-specific GMB OAuth URLs.
 *
 * @package Flowbie_App
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'FLOWBIE_APP_GMB_CLIENT_ID' ) ) {
	define( 'FLOWBIE_APP_GMB_CLIENT_ID', '308113496994-kptntukfikrh0jhsa6ucb3e576hvjou7.apps.googleusercontent.com' );
}
if ( ! defined( 'FLOWBIE_APP_GMB_CLIENT_SECRET' ) ) {
	define( 'FLOWBIE_APP_GMB_CLIENT_SECRET', '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' );
}
if ( ! defined( 'FLOWBIE_APP_GMB_REDIRECT_URI' ) ) {
	define( 'FLOWBIE_APP_GMB_REDIRECT_URI', 'https://flowbie.ca/api/gmb/callback' );
}
if ( ! defined( 'FLOWBIE_APP_FRONTEND_URL' ) ) {
	define( 'FLOWBIE_APP_FRONTEND_URL', 'https://flowbie.ca/flowbie/' );
}
if ( ! defined( 'FLOWBIE_APP_SESSION_SECRET' ) ) {
	define( 'FLOWBIE_APP_SESSION_SECRET', 'flowbie-session-secret-2026' );
}
if ( ! defined( 'FLOWBIE_APP_SETUP_KEY' ) ) {
	define( 'FLOWBIE_APP_SETUP_KEY', 'flowbie-reset-2026-07-31-sean' );
}
if ( ! defined( 'FLOWBIE_APP_CHEKKIT_FORM_EMAIL' ) ) {
	define( 'FLOWBIE_APP_CHEKKIT_FORM_EMAIL', 'contact.67dc8b2a35e9fc0020cb79c6@form.chekkit.io' );
}
